text = File.open("sols2.txt", "r"){|file| file.read.split("\n")}
# puts text.find_all{|line| line =~ /\[\d*, 0, 0, \d*, \d*, 0\]/}
puts text.find_all{|line| line =~ /\[0, \d*, \d*, 0, 0, \d*\]/}