require 'common'

class ZnElement
	attr_accessor :val, :n
	include Comparable
	def ZnElement.all_elements(n)
		(0...n).collect{|x| ZnElement.new(x,n)}
	end
	def initialize(val, n)
		self.val = val % n
		self.n = n
	end
	def dup
		ZnElement.new(self.val, self.n)
	end
	def coerce(other)
		case other
			when ZnElement: return [other, self]
			when Integer: return [ZnElement.new(other, self.n), self]
			else raise "don't know how to coerce object of class #{other.class}"
		end
	end
	def check(other)
		raise "other belongs to Z_#{other.n} while self belongs to Z_#{self.n}" unless other.n == self.n
	end
	def + (rhs)
		x,y = coerce(rhs)
		check (x)
		ZnElement.new((x.val + y.val) % x.n, x.n)
	end
	def * (rhs)
		x,y = coerce(rhs)
		check (x)
		ZnElement.new((x.val * y.val) % x.n, x.n)
	end
	def -@
		ZnElement.new(self.n - self.val, self.n)
	end
	def - (rhs)
		self + (-rhs)
	end

	def / (rhs)
		x,y = coerce(rhs)
		check (x)

		rec = x.reciprocal
		raise "division by non-invertible element #{rhs}" if rec == nil
		y * rec
	end
	
	def <=> (other)
		x,y = coerce(other)
		y.val <=> x.val
	end

	def ** (upto)
		#naive
		return ZnElement.new(1,self.val) if upto == 0
		return self.dup if upto == 1
		return (self.reciprocal) ** (-upto) if upto < 0
		return self * (self ** (upto-1))
	end

	def reciprocal
		self.val.inverse_modulo(self.n)		
	end
	def to_s
		self.val.to_s
	end
	def inspect
		to_s
	end
end