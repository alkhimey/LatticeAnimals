t = File.open("t", "r"){|file| file.read.split("\n")}
t.sort!{|a,b| a.length <=> b.length}
File.open("t", "w"){|file| file.write(t.join("\n"))}
