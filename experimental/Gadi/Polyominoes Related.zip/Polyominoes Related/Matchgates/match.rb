
require 'field'
require 'linear'
def all_binary_vectors(length)
	return [[0],[1]] if length == 1
	temp = all_binary_vectors(length - 1)
	result = []
	temp.each{|x| result << (x.dup << 0) << (x.dup << 1)}
	return result
end
class Integer
	def to_s_with_min_length(base = 10, min_length = 0)
		temp = to_s(base)
		while temp.length < min_length
			temp = "0" + temp
		end
		return temp
	end
end

class Array
	def cartesian_product(rhs)
		inject([]){|total, x| total + rhs.collect{|y| [x,y]}}
	end
	def tensor_product(rhs)
		#q,r of length l,m: q*r=s where s of length lm
		#s_{im+j}=q_i*r_j
		s=[]
		for i in (0...self.length)
			for j in (0...rhs.length)
				s << self[i]*rhs[j]
			end
		end
		s
	end
	def scalar_product(rhs)
		(0...length).inject(0){|sum, i| sum+self[i]*rhs[i]}
	end
	def forall
		each {|x| return false unless yield(x)}
		return true
	end
	def has_subset?(subset)
		subset.forall {|x| self.include?(x)}
	end
	def has_duplicates?
		self.length != self.uniq.length
	end
	def to_signature
		#assumes a binary vector of size 2**k
		k = (length-1).to_s(2).length
		(0...2**k).reject{|i| self[i] == 0}.collect {|x| x.to_s_with_min_length(2,k).split("").collect{|d| ((d == "0")?("n"):("p"))}.join("")}.join("+")
	end
	def binary_vector?
		forall{|x| x == 0 or x == 1}
	end
	def all_subsets
		all_binary_vectors(length).collect{|vec| (0...length).reject{|i| vec[i] == 0}.collect{|i| self[i]}}
	end
end

class Signature
	attr_accessor :array 
	def initialize(arr)
		@array = arr
	end
	def *(rhs)
		Signature.new(@array.tensor_product(rhs.array))
	end
	def +(rhs)
		raise "self of length #{@array.length} != rhs length #{rhs.array.length}" if @array.length != rhs.array.length
		s = Signature.new([])
		@array.each_index{|i| s.array << @array[i]+rhs.array[i]}
		s
	end
	def -(rhs)
		raise "self of length #{@array.length} != rhs length #{rhs.array.length}" if @array.length != rhs.array.length
		s = Signature.new([])
		@array.each_index{|i| s.array << @array[i]-rhs.array[i]}
		s
	end
	def to_s
		@array.inspect
	end
end

class Graph
	#undirected
	attr_accessor :vertices, :edges, :weights
	def initialize(opts)
		self.vertices = opts[:vertices] || []
		self.edges = opts[:edges] || []
		self.weights = opts[:weights] || {}
	end
	def dup
		Graph.new(:vertices => self.vertices.dup, :edges => self.edges.dup, :weights => self.weights.dup)
	end
	def add_edge(v1, v2)
		[v1,v2].each {|v| raise "the vertex #{v} is not in the vertex set #{self.vertices.inspect}" unless self.vertices.include?(v)}
		self.edges << [v1,v2].sort
		self.edges.uniq
		return self
	end
	def add_vertex(v)
		self.vertices << v
		self.vertices.sort.uniq
		return self
	end
	def remove_vertex(v)
		self.vertices.delete(v)
		self.edges.delete_if{|e| e.include?(v)}
	end
	def add_weight(edge, weight)
		raise "edge #{edge.inspect} not in graph!" unless self.edges.include?(edge.sort)
		self.weights[edge.sort] = weight
	end
	def << (item)
		if Array === item
			add_edge(*item) 
		else
			add_vertex(item)
		end
	end
	def to_s
		"vertices = #{self.vertices.inspect}\n" + "edges = #{self.edges.inspect}\n"
	end
	def edge_weight_product(edges)
		edges.inject(1){|prod, e| prod * (self.weights[e] || 1)}
	end
	def is_perfect_matching?(edges)
		return false unless self.edges.has_subset?(edges)
		return (self.vertices == edges.flatten.sort)
	end
	def count_perfect_matchings(current_edges = [], useable_edges = self.edges.dup)
		#counts all perfect matchings currently having current_edges in them
		#a naive backtracking algorithm    
		return 0 unless self.vertices.length % 2 == 0
		return edge_weight_product(current_edges) if is_perfect_matching?(current_edges)
		return 0 if current_edges.length * 2 == self.vertices.length #too many vertices...
		sum = 0
		while not useable_edges.empty?
			e = useable_edges.pop
			sum += count_perfect_matchings(current_edges + [e], useable_edges.dup)
		end
		return sum
	end
end

class Matchgate < Graph
	attr_accessor :input_vertices
	
	def initialize(opts)
		super(opts)
		self.input_vertices = opts[:input_vertices] || []
# 		self.output_vertices = opts[:output_vertices] || []
		@standard_signature = nil
	end
	def to_graph_without_inputs(input_vertices_to_remove)
		result = self.dup
		input_vertices_to_remove.each {|v| result.remove_vertex(v)}
		return result
	end
	def standard_signature_at(characteristic_vector)
		raise "characteristic_vector of size #{characteristic_vector.length} which is different from the number of input_vertices: #{self.input_vertices.length}" if characteristic_vector.length != self.input_vertices.length
		z = []
		characteristic_vector.each_index{|i| z << self.input_vertices[i] if characteristic_vector[i] == 1}
		to_graph_without_inputs(z).count_perfect_matchings
	end
	def standard_signature
		@standard_signature ||= all_binary_vectors(self.input_vertices.length).collect{|x| standard_signature_at(x)}
		@standard_signature
	end
	def generator_signature(base)
		#base is always thought of as [n,p]
		raise "base should be of size 2, not #{base.length}" if base.length != 2
		vectors = all_binary_vectors(self.input_vertices.length).collect {|x| x.collect{|a| base[a]}.inject([1]){|prod,t| prod.tensor_product(t)}}
		solution = solve_linear_equation_system(vectors, standard_signature)
		return nil if solution == nil or not solution.binary_vector?
		return solution.to_signature
	end
	def recognizer_signature(base)
		raise "base should be of size 2, not #{base.length}" if base.length != 2
		vectors = all_binary_vectors(self.input_vertices.length).collect {|x| x.collect{|a| base[a]}.inject([1]){|prod,t| prod.tensor_product(t)}}
		vectors.collect{|v| v.scalar_product(standard_signature)}
	end
end

# g = GeneratorMatchgate.new([1,2,3,4],[[1,2],[2,3],[3,4]],{},[1,2,3,4])
# g = GeneratorMatchgate.new([1,2,3,4,5,6],[[1,5],[2,5],[3,6],[4,6],[5,6]],{},[1,2,3,4])
# g = GeneratorMatchgate.new([1,2,3,4],[[1,2],[1,3],[1,4],[2,3],[2,4],[3,4]],{},[1,2,3,4])
# g = GeneratorMatchgate.new([1,2,3,4,5],[[1,2],[2,5],[3,5],[4,5]],{[1,2] => 1, [2,5] => 1},[1,2,3,4])
# g = GeneratorMatchgate.new([1,2,3,4],[[1,2],[2,3],[3,4],[1,3]],{[1,2] => 1, [2,5] => 1},[1,2,3,4])
# g = GeneratorMatchgate.new([1,2,3,4],[[1,2],[2,3],[2,4]],{[1,2] => 1},[1,2,3])
# g = GeneratorMatchgate.new([1,2,3,4,5],[[1,2],[2,3],[2,4],[1,5]],{[1,2] => 1},[1,2,3])
# g = GeneratorMatchgate.new([1,2,3,4,5,6],[[1,2],[2,3],[2,4],[1,5],[5,6],[4,6]],{[1,2] => 1},[1,2,3,4])
# g = GeneratorMatchgate.new([1,2,3,4,5,6],[[1,2],[2,3],[2,4],[1,5],[5,6],[4,6]],{[1,2] => 1},[1,2,3,4,5])
# g = GeneratorMatchgate.new([1,2,3,4,5,6],[[1,2],[2,3],[2,4],[1,5],[5,6],[2,6]],{[1,2] => 1},[1,2,3,4,5])


elements = ZnElement.all_elements(19)

possible_base_elements = elements.cartesian_product(elements)
possible_bases = possible_base_elements.cartesian_product(possible_base_elements)

vertices = [1,2,3]
edges = [[1,2],[1,3],[2,3]]
inputs = [1,2,3]
weights = {[1,2] => elements[1],[1,3] => elements[1],[2,3] => elements[1]}

g = Matchgate.new(:vertices => vertices, :edges => edges, :input_vertices => inputs)

puts possible_bases.collect{|base| g.generator_signature(base)}.compact.uniq

# puts g.standard_signature.inspect

# elements = ZnElement.all_elements(7)
# a = elements[4]
# b = elements[3]
# x = elements[4]
# y = elements[4]
# #
# base = [[a,b],[x,y]]
# puts g.generator_signature(base).inspect


# #   vertices = [1,2,3]
# #   outputs = [1,2,3]
# 
# all_edges = vertices.cartesian_product(vertices).collect{|x| x.sort}.uniq.reject{|x| x.first == x.last}
# 
# #   edges = all_edges.reject{|x| rand(2) == 0 or x.first == x.last}
#   
# #   puts edges.inspect
#  all_edges.all_subsets.each do |edges|
#   g = GeneratorMatchgate.new(vertices, edges, {}, outputs)
# # 	puts g.standard_signature.inspect
# # 	puts g.standard_signature.forall{|x| x == 0}
#    next if g.standard_signature.forall{|x| x == 0}
#   possible_values = (-1..1).to_a
#   possible_base_elements = possible_values.cartesian_product(possible_values)
#   possible_bases = possible_base_elements.cartesian_product(possible_base_elements)
# 
#   results = possible_bases.collect{|base| g.signature(base)}.compact.uniq
#         if not results.empty?
#                 puts "*************************"
#                 puts edges.inspect
#                 puts results
#         end
# end

#   puts possible_bases.collect{|base| g.signature(base)}.compact.uniq


# n = [0,1]
# p = [1,1]

# puts g.signature([n,p])
# puts g.edge_weight_product([[1,2]])
# puts g.weights[[1,2]]
# puts g.standard_signature.inspect

# puts g.count_perfect_matchings
# puts all_binary_vectors(3).inspect

# n = Signature.new([1,-1])
# p = Signature.new([0,1])
# 
# # we want the signature for (n*n*n*n)+(p*p*p*n)+(p*n*n*p)
# wanted_signature = (n*n*n*n) + (p*p*p*n) + (p*n*n*p)
# # 
# puts wanted_signature

# elements = ZnElement.all_elements(19)
# 
# possible_base_elements = elements.cartesian_product(elements)
# possible_bases = possible_base_elements.cartesian_product(possible_base_elements)

# possible_bases.each do |base|
# 	a,b,x,y = base[0][0], base[0][1], base[1][0], base[1][1]
# # 	a,b,x,y = 1,0,0,1
# 	sol = [
# 		a**3+x**3+a*x**2,
# 		(a**2)*b+(x**2)*y+(x**2)*b,
# 		(a**2)*b+(x**2)*y+x*y*a,
# 		a*(b**2)+x*(y**2)+x*y*b,
# 		a*(b**2)+x*(y**2)+(y**2)*a,
# 		b**3+y**3+b*(y**2)
# 	]
# 
# # 	puts "base: #{[a,b,x,y].inspect}\n Sol: #{sol.inspect}\n****************"
# 	puts "#{sol.inspect}"
# end