require 'test_helper'

class CounterHelperTest < ActionView::TestCase
end
