module CounterHelper
end
