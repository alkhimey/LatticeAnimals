#include "Polyomino.h"

void Polyomino::add_square(Square s){
    squares.push_back(s);
    size++;
}

void Polyomino::remove_square(Square s){
    if (squares.back() == s){ //for optimization purposes
        squares.pop_back();
        size--;
        return;
    }
    Squares::iterator i;
    for (i = squares.begin(); i<squares.end(); i++)
        if (*i == s){
            squares.erase(i);
            size--;
            return;
        }
}

void Polyomino::remove_last_square(){
    squares.pop_back();
    size--;
}

bool Polyomino::contains_square(Square s){
    Squares::iterator i;
    for (i = squares.begin(); i<squares.end(); i++)
        if (*i == s)
            return true;
    return false;
}
