/* 
 * File:   main.cpp
 * Author: gadial
 *
 * Created on March 21, 2010, 9:45 AM
 */

#include <stdlib.h>

#include <tclap/CmdLine.h>

#include "exceptions.h"
#include "RedelmeierAlgorithm.h"
#include "client.h"

/*
 * 
 */

#include "tests.h"
#ifdef DO_TESTS
#include <cppunit/CompilerOutputter.h>
#include <cppunit/extensions/TestFactoryRegistry.h>
#include <cppunit/ui/text/TestRunner.h>


int run_tests(){
  CPPUNIT_TEST_SUITE_REGISTRATION(SquareTest);
  CPPUNIT_TEST_SUITE_REGISTRATION(RedelmeierTest);
  CPPUNIT_TEST_SUITE_REGISTRATION(ConvexityTest);

  // Get the top level suite from the registry
  CppUnit::Test *suite = CppUnit::TestFactoryRegistry::getRegistry().makeTest();

  // Adds the test to the list of test to run
  CppUnit::TextUi::TestRunner runner;
  runner.addTest( suite );

  // Change the default outputter to a compiler error format outputter
  runner.setOutputter( new CppUnit::CompilerOutputter( &runner.result(),
                                                       std::cerr ) );
  // Run the tests.
  bool wasSucessful = runner.run();

  // Return error code 1 if the one of test failed.
  return wasSucessful ? 0 : 1;
}
#endif

vector<string> argv_parse(int argc, char* argv[]){
    vector<string> result;
    for (int i=0; i<argc; i++)
        result.push_back(argv[i]);
    return result;
}
int main(int argc, char** argv) {
    #ifdef DO_TESTS
    run_tests();
    return (EXIT_SUCCESS);
    #else
    if (argc > 1){
        cout << parse_and_run(argv_parse(argc, argv)) << endl;
    }
    else{
        Client c;
        c.run();
    }
    return (EXIT_SUCCESS);
    #endif
}


