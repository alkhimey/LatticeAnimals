/* 
 * File:   Square.h
 * Author: gadial
 *
 * Created on March 21, 2010, 9:55 AM
 */

#ifndef _MYSQUARE_H
#define	_MYSQUARE_H

#include <stdlib.h>
#include <vector>
#include <string>

using namespace std;
class Square;

typedef vector<Square> Squares;

void print_squares(Squares s);

class Square{
public:
    Square(int d, int coords[] = NULL);
    Square(const Square& rhs);
    virtual ~Square() {delete[] coordinates;};
    int operator[](int x) const;
    int& operator[](int x);
    static Square origin(int d);
    virtual Squares neighbors() const;
    virtual string to_s();

    virtual int cmp(const Square& rhs) const;
    bool operator<(const Square& rhs) const {return (cmp(rhs) == -1);}
    bool operator>(const Square& rhs) const {return (cmp(rhs) == 1);}
    bool operator==(const Square& rhs) const {return (cmp(rhs) == 0);}
    bool operator<=(const Square& rhs) const {return (cmp(rhs) != 1);}
    bool operator>=(const Square& rhs) const {return (cmp(rhs) != -1);}
    bool operator!=(const Square& rhs) const {return (cmp(rhs) != 0);}

    Square& operator=(const Square& rhs);

    bool is_legal(){return *this >= Square::origin(dimension);}
    Squares legal_neighbors() const;

    int get_dimension() const{return dimension;}

    int on_same_line(Square&);

    bool keeps_convexity(Squares&);
    void set_used_dimensions(bool* dimension_vector);
private:
    int dimension;
    int* coordinates;
};

ostream& operator<<(ostream& os, Square s);

#endif	/* _MYSQUARE_H */

