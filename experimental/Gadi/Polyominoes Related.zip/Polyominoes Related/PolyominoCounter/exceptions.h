/* 
 * File:   Exceptions.h
 * Author: gadial
 *
 * Created on March 21, 2010, 9:59 AM
 */

#ifndef _EXCEPTIONS_H
#define	_EXCEPTIONS_H

class BaseException{
    
};

class SquareCoordinateOutOfRangeException:public BaseException{
    
};

class SquareComparisionBetweenDifferentDimensionsException: public BaseException{
    
};

class NotLegalPolyominoTypeException: public BaseException{
    
};
#endif	/* _EXCEPTIONS_H */

