#include <string>
#include <vector>

using std::string;
using std::vector;
const bool DEBUG_MESSAGES = true;

const string default_server_address = "localhost:3000";
//const string default_server_address = "http://www.perm.gadial.net";
string parse_and_run(vector<string> args);

typedef enum {IDLE, HAS_TASK, WAIT, FINISHED_TASK, QUIT} status_vals;
class Client{
public:
    Client(string server_address = default_server_address):address(server_address), id(""), cmd(""), status(IDLE), debug_messages(DEBUG_MESSAGES){}
    void get_task();
    void do_task();
    void submit_task();
    void wait();
    void run();
    void log(string message);
private:
    std::vector<string> submission_data();
    
    string address;
    string id;
    string cmd;
    status_vals status;
    bool debug_messages;
    double time_taken;
    string result;
};
