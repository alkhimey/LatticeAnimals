#include "tests.h"
#include "square.h"
#include "RedelmeierAlgorithm.h"

#ifdef DO_TESTS

void SquareTest::test_to_s(){
    Square s2(2);
    Square s3(3);
    CPPUNIT_ASSERT("[0,0]" == s2.to_s());
    CPPUNIT_ASSERT("[0,0,0]" == s3.to_s());
    CPPUNIT_ASSERT("[0,0,0,0,0]" == Square::origin(5).to_s());
}

void SquareTest::test_assignment(){
    Square s(3);
    s[0] = 1; s[1] = -4; s[2] = 5;
    CPPUNIT_ASSERT(s[0] == 1 && s[1] == -4 && s[2] == 5);
    CPPUNIT_ASSERT("[1,-4,5]"==s.to_s());
}

void SquareTest::test_comparision(){
    Square s1(2), s2(2);
    s1[0] = 0; s1[1] = 0;
    s2[0] = 0; s2[1] = 0;

    CPPUNIT_ASSERT(s1.cmp(s2) == 0);
    CPPUNIT_ASSERT(s2.cmp(s1) == 0);
    CPPUNIT_ASSERT(s1 == s2);
    CPPUNIT_ASSERT(s1 <= s2);
    CPPUNIT_ASSERT(s1 >= s2);

    s2[0] = 1;
    CPPUNIT_ASSERT(s2 > s1);
    CPPUNIT_ASSERT(s2 >= s1);
    CPPUNIT_ASSERT(s1 < s2);
    CPPUNIT_ASSERT(s1 <= s2);
    CPPUNIT_ASSERT(s1 != s2);

    s2[0] = 0; s2[1] = 1;
    CPPUNIT_ASSERT(s2 > s1);
    CPPUNIT_ASSERT(s2 >= s1);
    CPPUNIT_ASSERT(s1 < s2);
    CPPUNIT_ASSERT(s1 <= s2);
    CPPUNIT_ASSERT(s1 != s2);

    CPPUNIT_ASSERT(s2.is_legal());
    s2[0] = -1;
    CPPUNIT_ASSERT(!s2.is_legal());
    s2[0] = 0; s2[1] = -1;
    CPPUNIT_ASSERT(!s2.is_legal());
    s2[0] = 1;
    CPPUNIT_ASSERT(s2.is_legal());
    s2[0] = 0; s2[1] = 1;
    CPPUNIT_ASSERT(s2.is_legal());
}

void SquareTest::test_neighbors(){
    Square s = Square::origin(2);
    Squares n = s.neighbors();
    Squares::iterator i = n.begin();
    s[0]=1; CPPUNIT_ASSERT(*i == s); i++; s[0]=0;
    s[0]=-1; CPPUNIT_ASSERT(*i == s); i++; s[0]=0;
    s[1]=1; CPPUNIT_ASSERT(*i == s); i++; s[1]=0;
    s[1]=-1; CPPUNIT_ASSERT(*i == s); i++; s[1]=0;
    n = s.legal_neighbors();
    i = n.begin();
    s[0]=1; CPPUNIT_ASSERT(*i == s); i++; s[0]=0;
    s[1]=1; CPPUNIT_ASSERT(*i == s); i++; s[1]=0;
}

void SquareTest::setUp(){

}

void SquareTest::tearDown(){

}

void RedelmeierTest::test_2d(){
    int n = 8;
    StandardInformation info(2);
    RedelmeierAlgorithm a = RedelmeierAlgorithm(n,info);
    a.run();
    mpz_class* results = a.get_results();
    int known_results[] = {1,1,2,6,19,63,216,760,2725,9910};
    for (int i=1; i<=n; i++)
        CPPUNIT_ASSERT(known_results[i] == results[i]);
}

void RedelmeierTest::test_3d(){
    int n = 6;
    StandardInformation info(3);
    RedelmeierAlgorithm a = RedelmeierAlgorithm(n,info);
    a.run();
//    a.print_results();
    mpz_class* results = a.get_results();
    int known_results[] = {1,1, 3, 15, 86, 534, 3481, 23502, 162913, 1152870, 8294738, 60494549};
    for (int i=1; i<=n; i++)
        CPPUNIT_ASSERT(known_results[i] == results[i]);
}

void RedelmeierTest::test_polyknight(){
    int n = 6;
    PolyknightInformation info;
    RedelmeierAlgorithm a = RedelmeierAlgorithm(n,info);
    a.run();
//    a.print_results();
//    mpz_class* results = a.get_results();
//    int known_results[] = {1,1, 3, 15, 86, 534, 3481, 23502, 162913, 1152870, 8294738, 60494549};
//    for (int i=1; i<=n; i++)
//        CPPUNIT_ASSERT(known_results[i] == results[i]);
}

void RedelmeierTest::test_proper(){
    {
        int n = 7;
        ProperPolyominoInformation info(2);
        RedelmeierAlgorithm a = RedelmeierAlgorithm(n,info);
        a.run();
        mpz_class* results = a.get_results();
        int known_results[] = {0,0,0,4,17,61,214,758};
        for (int i=1; i<=n; i++)
            CPPUNIT_ASSERT(known_results[i] == results[i]);
    }
    
    {
        int n = 6;
        ProperPolyominoInformation info(3);
        RedelmeierAlgorithm a = RedelmeierAlgorithm(n,info);
        a.run();
        mpz_class* results = a.get_results();
        int known_results[] = {0,0,0,0,32,348,2836};
        for (int i=1; i<=n; i++)
            CPPUNIT_ASSERT(known_results[i] == results[i]);
    }
}

void RedelmeierTest::setUp(){

}

void RedelmeierTest::tearDown(){

}

void ConvexityTest::setUp(){

}

void ConvexityTest::tearDown(){

}

void ConvexityTest::test_line_check(){
    int coords_a[] = {1,1,1};
    int coords_b[] = {2,1,1};
    int coords_c[] = {2,2,1};
    Square a(3, coords_a);
    Square b(3, coords_b);
    Square c(3, coords_c);
    CPPUNIT_ASSERT(a.on_same_line(b) == 0);
    CPPUNIT_ASSERT(b.on_same_line(c) == 1);
    CPPUNIT_ASSERT(a.on_same_line(c) == -1);
    CPPUNIT_ASSERT(a.on_same_line(a) == -1);
}

void ConvexityTest::test_keeps_convexity(){
    
}
#endif