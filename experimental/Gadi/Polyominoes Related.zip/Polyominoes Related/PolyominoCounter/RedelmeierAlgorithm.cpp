#include <iostream>
#include "RedelmeierAlgorithm.h"
#include <sstream>

void RedelmeierAlgorithm::run(){
    Squares untried_set;
    untried_set.push_back(info.origin());
//    improvedRecurse(untried_set);
    if (parallel_split_level > 0){
        parallel_recurse(untried_set);
    }
    else{
        recurse(untried_set);
    }
}

//void RedelmeierAlgorithm::naive_recurse(Squares& untried_set){
//    if (p.get_size() > max_n)
//        return;
////    p.print();
//    polyomino_count[p.get_size()] += 1;
//    while (untried_set.size() > 0){
//        Square new_square = untried_set.back();
//        untried_set.pop_back();
//        Squares new_untried_set = untried_set;
//        add_new_neighbors(new_untried_set, new_square);
//        p.add_square(new_square);
//        naive_recurse(new_untried_set);
//        p.remove_last_square();
//    }
//}

void RedelmeierAlgorithm::add_new_neighbors(Squares& untried_set, Square new_square){
    Squares neighbors = info.neighbors(new_square);
    Squares::iterator i,j;
    for (i=neighbors.begin(); i<neighbors.end(); i++){
        if (p.contains_square(*i))
            continue;
        Squares temp = info.neighbors(*i);
        bool to_add = true;
        for (j=temp.begin(); j<temp.end(); j++){
            if (p.contains_square(*j))
                to_add = false;
        }
        if (to_add)
            untried_set.push_back(*i);
    }
}

void RedelmeierAlgorithm::recurse(Squares& untried_set){
    //optimizing the neighbor adding procedure
    if (p.get_size() > max_n)
        return;
//    p.print();
    if (info.should_count(p))
        polyomino_count[p.get_size()] += 1;
    while (untried_set.size() > 0){
        Square new_square = untried_set.back();
        untried_set.pop_back();
        Squares new_untried_set = untried_set;
        Squares new_square_neighbors = info.neighbors(new_square);
        update_new_neighbors_addition(new_untried_set, new_square_neighbors);
        p.add_square(new_square);
        if (info.is_legal(*this,new_square)){
            parallel_recurse(new_untried_set);
        }
        p.remove_last_square();
        update_new_neighbors_deletion(new_square_neighbors);
    }
}

void RedelmeierAlgorithm::parallel_recurse(Squares& untried_set){
    //optimizing the neighbor adding procedure
    if (p.get_size() > max_n)
        return;
    if (info.should_count(p))
        polyomino_count[p.get_size()] += 1;
    if (p.get_size() != parallel_split_level || (parallel_split_start <= polyomino_count[p.get_size()] && parallel_split_stop >= polyomino_count[p.get_size()])){
        while (untried_set.size() > 0){
            Square new_square = untried_set.back();
            untried_set.pop_back();
            Squares new_untried_set = untried_set;
            Squares new_square_neighbors = info.neighbors(new_square);
            update_new_neighbors_addition(new_untried_set, new_square_neighbors);
            p.add_square(new_square);
            if (info.is_legal(*this,new_square)){
                parallel_recurse(new_untried_set);
            }
            p.remove_last_square();
            update_new_neighbors_deletion(new_square_neighbors);
        }
    }
}



void RedelmeierAlgorithm::update_new_neighbors_addition(Squares& untried_set, Squares& new_neighbors){
    Squares::iterator i;
    for (i=new_neighbors.begin(); i<new_neighbors.end(); i++){
        ref_count[*i] += 1;
        if (p.contains_square(*i) || ref_count[*i] != 1)
            continue;
        untried_set.push_back(*i);
    }
}

void RedelmeierAlgorithm::update_new_neighbors_deletion(Squares& new_neighbors){
    Squares::iterator i;
    for (i=new_neighbors.begin(); i<new_neighbors.end(); i++){
        ref_count[*i] -= 1;
        if (ref_count[*i] == 0)
            ref_count.erase(*i);
    }
}

void RedelmeierAlgorithm::print_results(){
//    cout << "[";
    for (int i=1; i<=max_n; i++)
        cout << polyomino_count[i] << (i<max_n ? ", " :"");
    cout << "\n";
}

string RedelmeierAlgorithm::results(){
    stringstream s;
//    cout << "[";
    for (int i=1; i<=max_n; i++)
        s << polyomino_count[i] << (i<max_n ? ", " :"");
    return s.str();
}

bool is_proper_polyomino(Polyomino& p, int d){
    bool* dimension_vector = new bool[d];
    for (int i=0; i<d; i++)
        dimension_vector[i] = false;
    for (Squares::iterator pos = p.get_squares().begin(); pos < p.get_squares().end(); pos++){
        (*pos).set_used_dimensions(dimension_vector);
    }
    bool result = true;
    for (int i=0; i<d; i++){
        result = (result && dimension_vector[i]);
    }
    delete[] dimension_vector;
    return result;
}

Squares PolyleaperInformation::neighbors(const Square& s){
    Squares result;
    Square temp = s;
    for (int i=-1; i<=1; i+=2)
        for (int j=-1; j<=1; j+=2)
        {
            temp = s; temp[0]+=i*a; temp[1]+=j*b; if (temp.is_legal()) result.push_back(temp);
            temp = s; temp[0]+=i*b; temp[1]+=j*a; if (temp.is_legal()) result.push_back(temp);
        }
    return result;
}

Squares PolyknightInformation::neighbors(const Square& s){
    Squares result;
    Square temp = s;
    temp = s; temp[0]+=1; temp[1]+=2; if (temp.is_legal()) result.push_back(temp);
    temp = s; temp[0]+=2; temp[1]+=1; if (temp.is_legal()) result.push_back(temp);
    temp = s; temp[0]-=1; temp[1]+=2; if (temp.is_legal()) result.push_back(temp);
    temp = s; temp[0]-=2; temp[1]+=1; if (temp.is_legal()) result.push_back(temp);
    temp = s; temp[0]+=1; temp[1]-=2; if (temp.is_legal()) result.push_back(temp);
    temp = s; temp[0]+=2; temp[1]-=1; if (temp.is_legal()) result.push_back(temp);
    temp = s; temp[0]-=1; temp[1]-=2; if (temp.is_legal()) result.push_back(temp);
    temp = s; temp[0]-=2; temp[1]-=1; if (temp.is_legal()) result.push_back(temp);
    return result;
}

Squares PolyzebraInformation::neighbors(const Square& s){
    Squares result;
    Square temp = s;
    temp = s; temp[0]+=2; temp[1]+=3; if (temp.is_legal()) result.push_back(temp);
    temp = s; temp[0]+=3; temp[1]+=2; if (temp.is_legal()) result.push_back(temp);
    temp = s; temp[0]-=2; temp[1]+=3; if (temp.is_legal()) result.push_back(temp);
    temp = s; temp[0]-=3; temp[1]+=2; if (temp.is_legal()) result.push_back(temp);
    temp = s; temp[0]+=2; temp[1]-=3; if (temp.is_legal()) result.push_back(temp);
    temp = s; temp[0]+=3; temp[1]-=2; if (temp.is_legal()) result.push_back(temp);
    temp = s; temp[0]-=2; temp[1]-=3; if (temp.is_legal()) result.push_back(temp);
    temp = s; temp[0]-=3; temp[1]-=2; if (temp.is_legal()) result.push_back(temp);
    return result;
}

bool TreePolyominoInformation::is_legal(RedelmeierAlgorithm& alg, Square& new_square){
//    cout << "legal? " << (alg.get_ref_count()[new_square] <= 1) << endl;
    return (alg.get_ref_count()[new_square] <= 1);
}

bool ProperTreePolyominoInformation::should_count(Polyomino& p){
    int d = origin().get_dimension();
    return is_proper_polyomino(p, d);
}

bool ProperPolyominoInformation::should_count(Polyomino& p){
    int d = origin().get_dimension();
    return is_proper_polyomino(p, d);
}

