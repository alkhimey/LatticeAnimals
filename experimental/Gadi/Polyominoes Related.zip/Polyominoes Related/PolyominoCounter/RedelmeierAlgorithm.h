/* 
 * File:   RedelmeierAlgorithm.h
 * Author: gadial
 *
 * Created on March 21, 2010, 3:30 PM
 */

#ifndef _REDELMEIERALGORITHM_H
#define	_REDELMEIERALGORITHM_H
#include <gmpxx.h>
#include <map>
#include "square.h"
#include "Polyomino.h"

class RedelmeierAlgorithm;

class RedelmeierInformation{
public:
    virtual Squares neighbors(const Square& s) = 0;
    virtual Square origin() = 0;
    virtual bool is_polyomino_legal(Polyomino& p) {return true;}
    virtual bool is_legal(RedelmeierAlgorithm& alg, Square& new_square){return true;}
    virtual bool should_count(Polyomino& p){return true;}
};

class RedelmeierAlgorithm{
public:
    RedelmeierAlgorithm(int n,RedelmeierInformation& _info, int p_split_level = 0, int p_start = 0, int p_stop = 0): max_n(n), info(_info), polyomino_count(new mpz_class[n+1]),
                                                            parallel_split_level(p_split_level),parallel_split_start(p_start),parallel_split_stop(p_stop){}
    ~RedelmeierAlgorithm(){delete[] polyomino_count;}
    void run();
    void naive_recurse(Squares& untried_set);
    
    void add_new_neighbors(Squares& untried_set, Square new_square);
    void print_results();
    mpz_class*  get_results(){return polyomino_count;}

    void recurse(Squares& untried_set);
    void parallel_recurse(Squares& untried_set);
    void update_new_neighbors_addition(Squares& untried_set, Squares& new_neighbors);
    void update_new_neighbors_deletion(Squares& new_neighbors);

    string results();

      map<Square,int> get_ref_count(){return ref_count;}
private:
    int max_n;
    RedelmeierInformation& info;
    mpz_class* polyomino_count;
    Polyomino p;
    map<Square,int> ref_count;
    int parallel_split_level;
    int parallel_split_start, parallel_split_stop;
};


class StandardInformation: public RedelmeierInformation{
public:
    StandardInformation(int d):dimension(d){};
    Squares neighbors(const Square& s){return s.legal_neighbors();}
    Square origin(){return Square::origin(dimension);}
    bool is_polyomino_legal(Polyomino& p){return true;}
private:
    int dimension;
};

class PolyleaperInformation: public RedelmeierInformation{
public:
    PolyleaperInformation(int _a, int _b):dimension(2),a(_a),b(_b){};
    Squares neighbors(const Square& s);
    Square origin(){return Square::origin(dimension);}
    bool is_polyomino_legal(Polyomino& p){return true;}
private:
    int dimension;
    int a,b;
};

class PolyknightInformation: public RedelmeierInformation{
public:
    PolyknightInformation():dimension(2){};
    Squares neighbors(const Square& s);
    Square origin(){return Square::origin(dimension);}
    bool is_polyomino_legal(Polyomino& p){return true;}
private:
    int dimension;
};

class PolyzebraInformation: public RedelmeierInformation{
public:
    PolyzebraInformation():dimension(2){};
    Squares neighbors(const Square& s);
    Square origin(){return Square::origin(dimension);}
    bool is_polyomino_legal(Polyomino& p){return true;}
private:
    int dimension;
};

class TreePolyominoInformation: public RedelmeierInformation{
public:
    TreePolyominoInformation(int d):dimension(d){};
    Squares neighbors(const Square& s){return s.legal_neighbors();}
    Square origin(){return Square::origin(dimension);}
    bool is_legal(RedelmeierAlgorithm& alg, Square& new_square);
private:
    int dimension;
};

class ProperTreePolyominoInformation: public TreePolyominoInformation{
public:
    ProperTreePolyominoInformation(int d):TreePolyominoInformation(d){};
    bool should_count(Polyomino& p);
};

class ProperPolyominoInformation: public RedelmeierInformation{
public:
    ProperPolyominoInformation(int d):dimension(d){}
    Squares neighbors(const Square& s){return s.legal_neighbors();}
    Square origin(){return Square::origin(dimension);}
    bool should_count(Polyomino& p);
private:
    int dimension;
};
#endif	/* _REDELMEIERALGORITHM_H */

