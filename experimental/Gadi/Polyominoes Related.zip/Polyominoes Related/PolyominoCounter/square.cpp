#include <sstream>
#include <iostream>

#include "square.h"
#include "exceptions.h"

void print_squares(Squares s){
   for (Squares::iterator i = s.begin(); i<s.end(); i++)
        cout << (*i);
   cout << endl;
}
Square::Square(int d, int coords[]): dimension(d) {
        coordinates = new int[d];
        for (int i=0; i<d; i++)
            coordinates[i] = (coords != NULL)?(coords[i]):(0);
};

Square::Square(const Square& rhs): dimension(rhs.dimension){
    coordinates = new int[dimension];
        for (int i=0; i<dimension; i++)
            coordinates[i] = rhs.coordinates[i];
}

Square& Square::operator=(const Square& rhs){
    if (this == &rhs)
        return *this;
    delete[] coordinates;
    dimension = rhs.dimension;
    coordinates = new int[dimension];
        for (int i=0; i<dimension; i++)
            coordinates[i] = rhs.coordinates[i];
    return *this;
}

int Square::operator[](int x) const{
    if (x < 0 || x >= dimension)
        throw SquareCoordinateOutOfRangeException();
    return coordinates[x];
}

int& Square::operator[](int x){
    if (x < 0 || x >= dimension)
        throw SquareCoordinateOutOfRangeException();
    return coordinates[x];
}

string Square::to_s(){
    ostringstream temp;
    temp << "[";
    for (int i=0; i<dimension; i++)
        temp << coordinates[i] << ",";
    int pos = temp.tellp();
    temp.seekp(pos-1);
    temp << "]";
    return temp.str();
}

Square Square::origin(int d){
    return Square(d);
}

ostream& operator<<(ostream& os, Square s){
    return (os << s.to_s());
}

int Square::cmp(const Square& rhs) const{
    if (dimension != rhs.dimension)
        throw SquareComparisionBetweenDifferentDimensionsException();
    for (int i=0; i<dimension; i++){
        if (coordinates[i] < rhs.coordinates[i])
            return -1;
        if (coordinates[i] > rhs.coordinates[i])
            return 1;
    }
    return 0;
}

Squares Square::neighbors() const{
    Squares result;
    for (int i=0; i<dimension; i++){
        Square temp1 = *this;
        Square temp2 = *this;
        temp1[i]+=1;
        temp2[i]-=1;
        result.push_back(temp1);
        result.push_back(temp2);
    }
    return result;
}

Squares Square::legal_neighbors() const{
    Squares result;
    for (int i=0; i<dimension; i++){
        Square temp1 = *this;
        Square temp2 = *this;
        temp1[i]+=1;
        temp2[i]-=1;
        if (temp1.is_legal())
            result.push_back(temp1);
        if (temp2.is_legal())
            result.push_back(temp2);
    }
    return result;
}

int Square::on_same_line(Square& rhs){
    int candidate = -1;
    for (int i=0; i<get_dimension(); i++){
        if (coordinates[i] != rhs.coordinates[i]){
            if (candidate != -1)
                return -1; //different on two coordinates at least - game over
            else
                candidate = i;
        }
    }
    return candidate;
}

bool Square::keeps_convexity(Squares& set){
    int d = get_dimension();
    int* max_vals = new int[d];
    int* min_vals = new int[d];
    int* num_vals = new int[d];

    for (int i = 0; i<= d; i++){
        max_vals[i] = coordinates[i];
        min_vals[i] = coordinates[i];
        num_vals[i] = 1;
    }
    for (Squares::iterator pos = set.begin(); pos<set.end(); pos++){
        int i = on_same_line(*pos);
        if (i == -1)
            continue;
        int new_val = (*pos)[i];

        if (max_vals[i] < new_val)
            max_vals[i] = new_val;
        
        if (min_vals[i] > new_val)
            min_vals[i] = new_val;

        num_vals[i]++;
    }

    bool result = true;
    for (int i=0; i<d && result; i++){
        result = (max_vals[i]-min_vals[i]+1 == num_vals[i]);
    }

    delete[] max_vals;
    delete[] min_vals;
    delete[] num_vals;

    return result;
}

void Square::set_used_dimensions(bool* dimension_vector){
    for (int i=0; i < dimension; i++){
        if (coordinates[i] != 0)
            dimension_vector[i] = true;
    }
}
