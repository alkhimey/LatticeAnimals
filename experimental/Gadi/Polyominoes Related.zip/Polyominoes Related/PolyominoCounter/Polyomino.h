/* 
 * File:   Polyomino.h
 * Author: gadial
 *
 * Created on March 21, 2010, 3:02 PM
 */

#ifndef _POLYOMINO_H
#define	_POLYOMINO_H
#include <map>
#include "square.h"

class Polyomino{
public:
    Polyomino():size(0){};
    void add_square(Square s);
    void remove_square(Square s);
    void remove_last_square();
    bool contains_square(Square s);
    int get_size() const{return size;}
    void print()const{print_squares(squares);}
    Squares& get_squares(){return squares;}
private:
    int size;
    Squares squares;
};
#endif	/* _POLYOMINO_H */

