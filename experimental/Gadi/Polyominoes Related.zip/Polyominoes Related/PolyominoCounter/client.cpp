#include "client.h"
#include <iostream>
#include <fstream>
#include <time.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <curl/curl.h>
#include <curl/types.h>
#include <curl/easy.h>

#include <vector>
#include <tclap/CmdLine.h>

#include <unistd.h>

#include "exceptions.h"
#include "RedelmeierAlgorithm.h"


using std::cout;
using std::endl;
using std::ofstream;
using std::vector;

/********************* cURL related stuff **********************/
struct MemoryStruct {
  char *memory;
  size_t size;
};

static void *myrealloc(void *ptr, size_t size);

static void *myrealloc(void *ptr, size_t size)
{
  /* There might be a realloc() out there that doesn't like reallocing
     NULL pointers, so we take care of it here */
  if(ptr)
    return realloc(ptr, size);
  else
    return malloc(size);
}

static size_t
WriteMemoryCallback(void *ptr, size_t size, size_t nmemb, void *data)
{
  size_t realsize = size * nmemb;
  struct MemoryStruct *mem = (struct MemoryStruct *)data;

  mem->memory = (char*)myrealloc(mem->memory, mem->size + realsize + 1);
  if (mem->memory) {
    memcpy(&(mem->memory[mem->size]), ptr, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = 0;
  }
  return realsize;
}

string http_get(string link)
{
  CURL *curl_handle;

  struct MemoryStruct chunk;

  chunk.memory=NULL; /* we expect realloc(NULL, size) to work */
  chunk.size = 0;    /* no data at this point */

  curl_global_init(CURL_GLOBAL_ALL);

  /* init the curl session */
  curl_handle = curl_easy_init();

  /* specify URL to get */
  curl_easy_setopt(curl_handle, CURLOPT_URL, link.c_str());

  /* send all data to this function  */
  curl_easy_setopt(curl_handle, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);

  /* we pass our 'chunk' struct to the callback function */
  curl_easy_setopt(curl_handle, CURLOPT_WRITEDATA, (void *)&chunk);

  /* some servers don't like requests that are made without a user-agent
     field, so we provide one */
  curl_easy_setopt(curl_handle, CURLOPT_USERAGENT, "libcurl-agent/1.0");

  /* get it! */
  curl_easy_perform(curl_handle);

  /* cleanup curl stuff */
  curl_easy_cleanup(curl_handle);

  /*
   * Now, our chunk.memory points to a memory block that is chunk.size
   * bytes big and contains the remote file.
   *
   * Do something nice with it!
   *
   * You should be aware of the fact that at this point we might have an
   * allocated data block, and nothing has yet deallocated that data. So when
   * you're done with it, you should free() it as a nice application.
   */
  string result(chunk.memory);

  if(chunk.memory)
    free(chunk.memory);

  /* we're done with libcurl, so clean it up */
  curl_global_cleanup();

  return result;
}

void http_post(string link, vector<string> vals)
{
  CURL *curl;
  CURLcode res;

  struct MemoryStruct chunk;

  chunk.memory=NULL; /* we expect realloc(NULL, size) to work */
  chunk.size = 0;    /* no data at this point */

  struct curl_httppost *formpost=NULL;
  struct curl_httppost *lastptr=NULL;
  struct curl_slist *headerlist=NULL;
  static const char buf[] = "Expect:";

  curl_global_init(CURL_GLOBAL_ALL);
//    cout << "adding the following parameters:" << endl;
  for (vector<string>::iterator i = vals.begin(); i < vals.end(); i++){
      string field_name = *i;
      i++;
      string field_data = *i;
//      cout << field_name << " => " << field_data << endl;
      curl_formadd(&formpost,
               &lastptr,
               CURLFORM_COPYNAME, field_name.c_str(),
               CURLFORM_COPYCONTENTS, field_data.c_str(),
               CURLFORM_END);
  }

  curl = curl_easy_init();
  /* initalize custom header list (stating that Expect: 100-continue is not
     wanted */
  headerlist = curl_slist_append(headerlist, buf);
  if(curl) {
    /* what URL that receives this POST */
    curl_easy_setopt(curl, CURLOPT_URL, link.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headerlist);
    curl_easy_setopt(curl, CURLOPT_HTTPPOST, formpost);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);

    
    res = curl_easy_perform(curl);

    /* always cleanup */
    curl_easy_cleanup(curl);

    /* then cleanup the formpost chain */
    curl_formfree(formpost);
    /* free slist */
    curl_slist_free_all (headerlist);
  }
}

/********************* cURL related stuff **********************/

void rest(unsigned int mseconds)
{
    cout << "sleep started\n";
    clock_t goal = mseconds + clock();
    while (goal > clock()){
//        cout << "clock: " << clock() << ", goal: " << goal << endl;
    };
    cout << "sleep ended\n";
}

void tokenize(const string& str,
                      vector<string>& tokens,
                      const string& delimiters = " ")
{
    // Skip delimiters at beginning.
    string::size_type lastPos = str.find_first_not_of(delimiters, 0);
    // Find first "non-delimiter".
    string::size_type pos     = str.find_first_of(delimiters, lastPos);

    while (string::npos != pos || string::npos != lastPos)
    {
        // Found a token, add it to the vector.
        tokens.push_back(str.substr(lastPos, pos - lastPos));
        // Skip delimiters.  Note the "not_of"
        lastPos = str.find_first_not_of(delimiters, pos);
        // Find next "non-delimiter"
        pos = str.find_first_of(delimiters, lastPos);
    }
}

string parse_and_run(vector<string> args){
    int dimension;
    int n;
    int type;
    int a,b;
    int parallel_level, parallel_start, parallel_stop;
    try {
	TCLAP::CmdLine cmd("Polyomino Counter", ' ', "0.1");
        TCLAP::ValueArg<int> sizeArg("n","number","Maximum size",true,0,"integer");
	TCLAP::ValueArg<int> dimensionArg("d","dimension","Dimension",false,2,"integer");
        TCLAP::ValueArg<int> typeArg("t","type","Type",false,0,"integer");
        TCLAP::ValueArg<int> parallelArg("p","parallel","Parallel",false,0,"integer");
        TCLAP::ValueArg<int> p_startArg("s","pstart","Parallel start",false,0,"integer");
        TCLAP::ValueArg<int> p_stopArg("r","pstop","Parallel stop",false,0,"integer");
        TCLAP::ValueArg<int> aArg("a","a_parameter","a Parameter",false,0,"integer");
        TCLAP::ValueArg<int> bArg("b","b_parameter","b Parameter",false,0,"integer");


        cmd.add( bArg );
        cmd.add( aArg );
        cmd.add( p_stopArg );
        cmd.add( p_startArg );
        cmd.add( parallelArg );
        cmd.add( typeArg );
        cmd.add( dimensionArg );
        cmd.add( sizeArg );

        cmd.parse(args);

	dimension = dimensionArg.getValue();
        n = sizeArg.getValue();
        type = typeArg.getValue();

        a = aArg.getValue();
        b = bArg.getValue();

        parallel_level = parallelArg.getValue();
        parallel_start = p_startArg.getValue();
        parallel_stop = p_stopArg.getValue();

    } catch (TCLAP::ArgException &e)  // catch any exceptions
	{ std::cerr << "error: " << e.error() << " for arg " << e.argId() << std::endl; }

    RedelmeierInformation* info;

    switch(type){
        case 0: info = new StandardInformation(dimension); break;
        case 1: info = new PolyleaperInformation(a,b); break;
        case 2: info = new TreePolyominoInformation(dimension); break;
        case 3: info = new ProperTreePolyominoInformation(dimension); break;
        default: throw NotLegalPolyominoTypeException();
    }

    RedelmeierAlgorithm alg = RedelmeierAlgorithm(n,*info, parallel_level, parallel_start, parallel_stop);

    alg.run();
    string results = alg.results();
    delete info;
    return results;
}

string tokenize_and_run(string cmd){
    vector<string> args;
    tokenize(cmd,args," ");
    return parse_and_run(args);
}

string get_data_from_div_tag(string source, string tag_id){
    size_t pos = source.find("<div id=\"" + tag_id + "\">");
    if (pos == string::npos){
        return "";
    }
    size_t start = pos + string("<div id=\"" + tag_id + "\">").length();
    size_t end = source.find("</div>",pos);
    return source.substr(start, end-start);
}

void Client::log(string message){
    if (debug_messages){
        ofstream logfile("log.txt", ios::out | ios::app);
        logfile << time(NULL) << ": " << message << endl;
    }
}
void Client::get_task(){
    try{
        log("getting task");
        string res = http_get(address + "/counter/get_task");
        size_t pos = res.find("No task avialable");
        if (pos != string::npos){
            log("got no task");
            status = WAIT;
        }
        else{
            id = get_data_from_div_tag(res,"task_id");
            cmd = get_data_from_div_tag(res,"task_cmd_line");
            log("got task no. " + id + ": " + cmd);
            status = HAS_TASK;
            if (id == ""){
                status = WAIT;
            }
        }
    }
    catch(std::logic_error){
        log("Had some error connecting to the server");
        status = WAIT;
    }
}

vector<string> Client::submission_data(){
    stringstream time_taken_string;
    time_taken_string << time_taken;

    vector<string> data;
    data.push_back("id");
    data.push_back(id);
    data.push_back("result");
    data.push_back(result);
    data.push_back("time");
    data.push_back(time_taken_string.str());
    return data;
}

void Client::do_task(){
    log("doing task " + cmd);
    clock_t start = clock();
    result = tokenize_and_run(cmd);
    time_taken = clock();
    time_taken -= start;
    time_taken /= CLOCKS_PER_SEC;
    status = FINISHED_TASK;
    log("Finished task. Results = " + result);
}

void Client::submit_task(){
    log("submitting task");
    http_post(address + "/counter/submit_task", submission_data());
    status = IDLE;
}

void Client::wait(){
    log("sleeping...");
    for (int i=0; i<600; i++)
        usleep(100000);
    status = IDLE;
}

void Client::run(){
    cout << "Program is running, everything is ok so far." << endl;
    bool run = true;
    while (run){
        switch(status){
            case IDLE:          get_task();     break;
            case HAS_TASK:      do_task();      break;
            case FINISHED_TASK: submit_task();  break;
            case WAIT:          wait();         break;
            case QUIT:          run = false;    break;
        }
    }
}
