/* 
 * File:   Tests.h
 * Author: gadial
 *
 * Created on March 21, 2010, 10:18 AM
 */


#ifndef _TESTS_H
#define	_TESTS_H



#include "square.h"
//#define DO_TESTS
#ifdef DO_TESTS

#include <cppunit/extensions/HelperMacros.h>

class SquareTest : public CppUnit::TestFixture{
    CPPUNIT_TEST_SUITE( SquareTest );
    CPPUNIT_TEST( test_to_s );
    CPPUNIT_TEST( test_assignment );
    CPPUNIT_TEST( test_comparision );
    CPPUNIT_TEST( test_neighbors );
    CPPUNIT_TEST_SUITE_END();
public:
    void setUp();
    void tearDown();

    void test_to_s();
    void test_assignment();
    void test_comparision();
    void test_neighbors();
};

class RedelmeierTest : public CppUnit::TestFixture{
    CPPUNIT_TEST_SUITE( RedelmeierTest );
    CPPUNIT_TEST( test_2d );
    CPPUNIT_TEST( test_3d );
    CPPUNIT_TEST( test_polyknight );
    CPPUNIT_TEST( test_proper );
    CPPUNIT_TEST_SUITE_END();
public:
    void setUp();
    void tearDown();

    void test_2d();
    void test_3d();
    void test_polyknight();
    void test_proper();
};

class ConvexityTest : public CppUnit::TestFixture{
    CPPUNIT_TEST_SUITE( ConvexityTest );
    CPPUNIT_TEST( test_line_check );
    CPPUNIT_TEST( test_keeps_convexity );
    CPPUNIT_TEST_SUITE_END();
public:
    void setUp();
    void tearDown();
    void test_line_check();
    void test_keeps_convexity();
};

#endif
#endif	/* _TESTS_H */

