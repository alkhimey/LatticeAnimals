require 'frac'
class Polynomial
	attr_reader :coefficients
	def initialize(coefficients)
		@coefficients = coefficients
	end
	def [](i)
		@coefficients[i]
	end
	def []=(i,val)
		@coefficients[i] = val
	end
	def dup
		Polynomial.new(@coefficients.dup)
	end
	def degree
		deg = 0
		@coefficients.each_index{|i| deg = i if @coefficients[i] != 0}
		return deg
	end
	def reduce!
		@coefficients = @coefficients[0..degree]
	end
	def var_to_s(i)
	    case i
		when 0 then return ""
		when 1 then return "x"
		else "x^#{i}"
	    end
	end
	def to_s
		s = ""
		degree.downto(0) do |i|
			s += (@coefficients[i].to_s + var_to_s(i)) unless @coefficients[i] == 0
			s += "+" if i>0 and @coefficients[i-1] > 0
		end
		return s
	end
	def +(rhs)
		result_coefficients = []
		0.upto([degree, rhs.degree].max) {|i| result_coefficients << (self[i] || 0) + (rhs[i] || 0)}
		Polynomial.new(result_coefficients)
	end
	def -(rhs)
		result_coefficients = []
		0.upto([degree, rhs.degree].max) {|i| result_coefficients << (self[i] || 0) - (rhs[i] || 0)}
		Polynomial.new(result_coefficients)
	end
	def *(rhs)
	    result_coefficients = [0]*(degree+rhs.degree+1)
	    0.upto(degree){|i| 0.upto(rhs.degree) {|j| result_coefficients[i+j] += self[i]*rhs[j]}}
	    Polynomial.new(result_coefficients)
	end
	def **(rhs)
		raise "Cannot raise by #{rhs.class} power" unless Integer === rhs
		(1..rhs).inject(Polynomial.new([1])){|p, i| p*self}
	end
	def multiply_by_scalar!(scalar)
		@coefficients.collect!{|x| x*scalar}
		self
	end
	def multiply_by_scalar(scalar)
		dup.multiply_by_scalar!(scalar)
	end
	def evaluate(x)
	    temp = 1
	    sum = 0
	    @coefficients.each_index do |i|
		sum += @coefficients[i]*temp
		temp *= x
	    end
	    sum
	end
	def derivative
		new_coefficients = []
		1.upto(degree) do |i|
			new_coefficients << @coefficients[i]*i
		end
		Polynomial.new(new_coefficients)
	end
	def ==(rhs)
		@coefficients[0..degree] == rhs.coefficients[0..rhs.degree]
	end
	def -@
		multiply_by_scalar(-1)
	end
	def substitute_x_for(q)
		#substitues the polynomial p instead of x
		(0..degree).inject(Polynomial.new([0])){|p, i| p + (q**i).multiply_by_scalar(@coefficients[i])}
	end
	
end

def divided_difference(vals)
    n = vals.length - 1
    return vals[0].last if n == 0
    return Frac.new((divided_difference(vals[0..(n-1)])-divided_difference(vals[1..n])), (vals[0].first - vals[n].first))
end

def basis_polynomial(i, points)
    (0...i).inject(Polynomial.new([1])){|n_pol, j| n_pol*Polynomial.new([-points[j].first,1])}
end

def divided_coefficient(i, points)
    Polynomial.new([divided_difference(points[0..i])])
end

def newton_interpolation(points)
     (0...points.length).inject(Polynomial.new([0])) do |pol, i|
	pol + divided_coefficient(i,points)*basis_polynomial(i,points)
     end
end