require 'polynomial'
class Polynomial
	def Polynomial.falling_factorial(n)
		(0...n).collect{|i| Polynomial.new([-i,1])}.inject(Polynomial.new([1])){|prod, p| prod*p}
	end
end

class Integer
	def factorial
		(2..self).inject(1){|prod, x| prod*x}
	end
end

class Array
	def differences
		result = []
		each_index{|i| result << self[i]-self[i-1] unless i==0}
		result
	end
	def all_differences
		result = []
		temp = self
		while not temp.empty?
			result << temp
			temp = temp.differences
		end
		result
	end

	def finite_difference_interpolation(from = nil, degree = nil)
		differences = ((from == nil)?(all_differences):(self[from..-1].all_differences))
		return nil if degree and differences.length <= degree
		degree = differences.reject{|d| d.first == 0 and d.last == 0}.length - 1 unless degree
		result_polynomial = (0..degree).inject(Polynomial.new([0])) do |result, n|
			result + Polynomial.falling_factorial(n).multiply_by_scalar(Frac[differences[n].first,n.factorial])
		end
 		result_polynomial = result_polynomial.substitute_x_for(Polynomial.new([-from,1])) if from
		return result_polynomial
	end
	def newton_interpolate
		newton_interpolation((0...length).collect{|n| [n,self[n]]})
	end
end

def predicted_sequence(polynomial, max)
	(0..max).collect{|i| polynomial.evaluate(i).to_i}
end

# p = [3, 6, 2, 8, 3,7,7,7].finite_difference_interpolation
# puts predicted_sequence(p,20).inspect
# (0..10).each{|n| puts "#{n}: #{Polynomial.falling_factorial(n)}"}
# require 'benchmark'
# 
# degree = 8
# max_coefficient = 100
# coefficients = (0..degree).collect{rand(max_coefficient)}
# p = Polynomial.new(coefficients)
# s = predicted_sequence(p,12)
# 
# # p1 = s.finite_difference_interpolation
# # p2 = s.newton_interpolate
# 
# Benchmark.bmbm(20) do |x|
# 	x.report("Newton:") {s.newton_interpolate}
# 	x.report("Finite difference:") {s.finite_difference_interpolation}
# end