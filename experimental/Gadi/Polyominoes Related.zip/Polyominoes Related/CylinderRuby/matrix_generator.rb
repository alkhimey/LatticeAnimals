#!/usr/bin/env ruby
require 'DoubleArray'
require 'matrix'
class DoubleArray
	def sum_neighbors(x,y)
		return if x+1==@size_x
		sum=self[x+1,y]
		sum=sum+self[x+1,y+1] unless y+1==@size_y
		sum=sum+self[x+1,y-1] unless y-1<0
		return sum
	end
end

class Array
  def count
    res = {}
    each{|x| res[x] ||=0; res[x]+=1}
    res
  end
end

class Matrix
  def []=(i, j, x)
    @rows[i][j] = x
  end
  def to_s
    @rows.collect{|row| row.inspect}.join("\n")
  end
end

class Integer
  def sign_string
    return "+" if self>=0
    return "-"
  end
end

class SimplerArray < Array
	def [](sheep)
		return nil if Range === sheep and sheep.end < sheep.begin
    		super sheep
  	end
end

class MotzkinPathInformation
	attr_reader :paths_number
	def initialize(n, max_height=n / 2)
		@length=n
		@max_height=max_height
		@paths_number=DoubleArray.new(n+1,max_height+1)
		@paths_number.each_index{|x,y| @paths_number[x,y]=0}
		@paths_number[n,0]=1 #initial condition: 1 for the the rightmost down corner
		(@length-1).downto(0) do |x|
			(max_height+1).times do |y|
				@paths_number[x,y]=@paths_number.sum_neighbors(x,y)
			end
		end
	end
	def canonical_last_cell
		#returns the cell of {<W>}
		path = [0]*@length
		path[-1] = -1
		path[-2] = 1
		moztkin_path_to_number(path)
	end
	def canonical_first_cell
		#returns the cell of {<W>}
		path = [0]*@length
		path[0] = 1
		path[1] = -1
		moztkin_path_to_number(path)
	end
	def number_to_moztkin_path(n)
		path=[]
		y=0 #inital height
		raise "n=#{n} is too big (not smaller than #{@paths_number[0,0]})" if n>=@paths_number[0,0]
		@length.times do |x|
			if y>0 and n<@paths_number[x+1,y-1]
				path[x]=-1 #going down
				y=y-1
				next
			else
				n=n-@paths_number[x+1,y-1] if y>0
			end
			if n<@paths_number[x+1,y]
				path[x]=0
				next
			else
				n=n-@paths_number[x+1,y]
			end
			path[x]=1
			y=y+1
		end
		return path
	end

	def moztkin_path_to_number(path)
		return nil unless path
		raise "Path length (#{path.size} does not match expected (#{@length}) length" if path.size != @length
		n,y=0,0
		@length.times do |x|
			case path[x]
				when 1
					n=n+@paths_number[x+1,y]
					n=n+@paths_number[x+1,y-1] if y>0
					y=y+1
					#raise "Path #{path.inspect} illegal - went above y=#{@max_height}" if y>@max_height
					return nil if y>@max_height
				when 0
					n=n+@paths_number[x+1,y-1] if y>0
				when -1
					y=y-1
					#raise "Path #{path.inspect} illegal - went below y=0" if y<0 
					return nil if y<0 
			end
		end
		return n
	end
	def find_A(path) # the smallest index>0 for which the path is of height 0
		y=0 #current height
		@length.times do |x|
			y=y+path[x]
			return (x+1) if y==0
		end
		raise "A is undefined for #{path.inspect}"
	end
	def find_B(path) # the largest index<length for which the path is of height 0
		y=0 #current height
		(@length-1).downto(0) do |x|
			y=y-path[x] #going "backwards"
			return x if y==0
		end
		raise "B is undefined for #{path.inspect}"
	end
	def find_C(path) # the largest index < length-1 for which the path is of height 1
		y=0 #current height
		(@length-1).downto(0) do |x|
			y=y-path[x] #going "backwards"
			return x if y==1 and x<@length-1
		end
		raise "C is undefined for #{path.inspect}"
	end
	def succ0(path) #based on pg. 24 in the article
		return unless path
		return moztkin_path_to_number(succ0(number_to_moztkin_path(path))) if Integer===path 
		p=SimplerArray.new(path)
		w=@length-1 #to be coherent with the article
		begin a,b,c=find_A(p),find_B(p),find_C(p); rescue RuntimeError; end
		case p.inspect
			when %r{.*0\]}: output=[0,p[0..w-1]]
			when %r{.*0, -1\]}: output=[0,p[0..w-2],-1]
			when %r{.*-1, -1\]}: output=[0,p[0..c-1],-1,p[c+1..w-2],0] #note: the paper says here b, not c, which I believe to be a mistake!
			when %r{.*1, -1\]}: return @vector_size
		end
		return output.flatten.compact
	end
	def succ1(path) #based on pg. 24 in the article
		return moztkin_path_to_number(succ1(number_to_moztkin_path(path))) if Integer===path 
		p=SimplerArray.new(path)
		w=@length-1 #to be coherent with the article
		begin a,b,c=find_A(p),find_B(p),find_C(p); rescue RuntimeError; end
		case p.inspect
			when %r{\[0.*0\]}: output=[1,-1,p[1..w-1]]
			when %r{\[1.*0\]}: output=[1,0,p[1..w-1]]
			when %r{\[0.*[^-]1, -1\]}: output=[1,-1,p[1..w-2],0]
			when %r{\[1.*[^-]1, -1\]}: output=[1,0,p[1..w-2],0]
			when %r{\[0.*0, -1\]}: output=[1,1,p[1..b-1],-1,p[b+1..w-2],-1]
			when %r{\[1.*0, -1\]}: output=case
						when a==w+1: [1,0,p[1..w-2],-1] # note: the paper says [0..W-2] which is a mistake!
						else [1,0,p[1..a-2],1,p[a..b-1],-1,p[b+1..w-2],-1]
						end
			when %r{\[0.*-1, -1\]}: output=[1,1,p[1..b-1],-1,p[b+1..c-1],-1,p[c+1..w-2],0]
			when %r{\[1.*-1, -1\]}: output=case
						when a==w+1: [1,0,p[1..c-1],-1,p[c+1..w-2],0]
						else [1,0,p[1..a-2],1,p[a..b-1],-1,p[b+1..c-1],-1,p[c+1..w-2],0]
						end
		end
		return output.flatten.compact
	end

	def new_iteration_vector
		x=[0]*(@succ0.length)
		x[canonical_last_cell] = 1
		x.size.times do |i|
		    x[i] += x[@succ0[i]] if @succ0[i]
		end
		x
	end
	def compute_succ
		@succ0=[]
		@succ1=[]
		@paths_number[0,0].times {|i| @succ0 << succ0(i); @succ1 << succ1(i)}
		sink = @succ0.length
		@succ0 << sink
		@succ1 << sink
		@succ0.collect!{|x| ((x)?(x):(sink))}
	end
	def iterate(old)
 		new=[0]*old.size
		old.size.times do |i|
			new[i] += new[@succ0[i]] if @succ0[i]
			new[i] += old[@succ1[i]] if @succ1[i]
		end
		new
	end
	def print_path_info(path)
		puts "path=#{path.inspect}: A=#{find_A(path)} B=#{find_B(path)} C=#{find_C(path)} W=#{path.length-1}"
	end
	def print_succ
		puts "succ0 (size #{@succ0.length})=#{@succ0.inspect}"
		puts "succ1 (size #{@succ0.length})=#{@succ1.inspect}"
	end
	def vector_size
	  @paths_number[0,0]
	end
	def matrix
# 	  puts @succ0.inspect
# 	  puts @succ1.inspect
# 	  puts
	  n = @succ0.length-1
	  matrix = Matrix.zero(n)
	  for i in 1..n do
	    for k in 0..@length-2 do
	      j = @succ1[i]
	      k.times {j = @succ0[j]}
	      matrix[i-1,j-1] = matrix[i-1,j-1] + 1 unless j == nil
	    end
	  end
	  matrix
	end
end

def generate_matrix(w)
    t=MotzkinPathInformation.new(w)
    t.compute_succ
    m = t.matrix
    rows = (0...m.row_size-1).collect{|i| m.row(i)}.collect{|r| r[0...-1]}
    Matrix[*rows]
end

def generate_matrices(max_w = 10)
  for w in (3..max_w)
    File.open("m#{w}","w"){|file| file.puts(generate_matrix(w))}
  end
end

def find_GF(w)
  matrix_file = "m#{w}"
  File.open(matrix_file,"w"){|file| file.puts(generate_matrix(w))}
  `sage reglang.sage #{matrix_file} GF`
end

def find_recurrence(w)
  matrix_file = "m#{w}"
  File.open(matrix_file,"w"){|file| file.puts(generate_matrix(w))}
  `sage reglang.sage #{matrix_file}` =~ /\[(.*)\]/
  return "" unless $1
  coefficients = $1.split(", ").collect{|x| x.to_i}
  raise "leading coefficient not 1" unless coefficients.last == 1
  recurrence = "a_n = "
  k = 1
  for a in coefficients[0...-1].reverse do
    next if a == 0
    a *= -1
    string_to_add = ""
    string_to_add = "#{a.sign_string} " if k!= 1
    string_to_add = "-" if k == 1 and a < 0
    string_to_add += "#{a.abs}" unless a.abs == 1
    string_to_add += "a_{n-#{k}} "
    recurrence += string_to_add
    k+=1
  end
  recurrence + "\n" + generate_reucrrence_kernel(w,k).inspect
end

def generate_reucrrence_kernel(w, max)
  t=MotzkinPathInformation.new(w)
  t.compute_succ
  vector=t.new_iteration_vector
  values = []
    (max-1).times do |i|
      vector = t.iterate(vector)
      values << vector[t.canonical_last_cell]
   end
   values
end

w = 5
puts find_recurrence(w) 
puts find_GF(w)

# for w in (3..10) do 
#   puts "w = #{w-1}"
#   puts find_recurrence(w) 
#   puts find_GF(w) if w<=7
# end

# m = generate_matrix(11)
# 
# vals = []
# m.row_size.times do |i|
#   m.column_size.times do |j|
#     vals << m[i,j]
#   end
# end
# 
# c = vals.count
# puts c.inspect
# puts 100*c[1]/(c[1]+c[0])



# generate_matrices


# w = 5
# t=MotzkinPathInformation.new(w)
# t.compute_succ
# m = t.matrix
# 
# # puts m
# 
# 
# rows = (0...m.row_size-1).collect{|i| m.row(i)}.collect{|r| r[0...-1]}
# 
# temp_m = Matrix[*rows]


# v = Matrix[[1]+[0]*(temp_m.row_size - 1)].transpose
# 
# puts (1..20).collect{v = temp_m*v; v[0,0]}.inspect

# vals = []
# temp_m.row_size.times do |i|
#   temp_m.column_size.times do |j|
#     vals << temp_m[i,j]
#   end
# end
# 
# puts vals.uniq.inspect

# puts temp_m
# puts m
# max_n = 100
# 
# values = DoubleArray.new(max_n+1, max_w+1)
# (3..max_w).each do |w|
# #     puts "starting for w=#{w}"
#     t=MotzkinPathInformation.new(w)
#     succ_compute_time_start=Time.new
#     t.compute_succ
#     succ_compute_time_end=Time.new
# #      puts "Successors calculated. Time taken=#{(succ_compute_time_end-succ_compute_time_start).to_f}"
# 
#     vector=t.new_iteration_vector
# 
#     iteration_compute_time_start=Time.new
# 
#     (max_n-1).times do |i|
# 	    vector = t.iterate(vector)
# 	    values[i+2,w]=vector[t.canonical_last_cell]
#     end
# end
# 
# (3..max_w).each do |w|
#   puts "W = #{w-1}"
#   puts (1...max_n).collect{|n| values[n+1,w]}.inspect
# end

# puts values.inspect

# spacer = "\t"
# print "#{spacer}#{1}#{spacer}"
# (3..max_w).each {|w| print("#{w-1}#{spacer}")}
# puts
# row_num = -1
# (1..max_n).each do |n|
#     print "#{n}#{spacer}1#{spacer}"
#     (3..max_w).each {|w| print("#{values[n+1,w]}#{spacer}")}
#     puts
# end
