#An implementation of Jensen's algorithm for counting polyominoes
$DebugPrint = false

class Array
	def simple_sum(other)
		result = []
		([self.length, other.length].max).times {|i| result[i] = (self[i] || 0)  + (other[i] || 0)}
		result
	end
	def shift_right
		[0] + self
	end
end

class Signature
	attr_accessor :cells
	attr_accessor :touching_up, :touching_down
	def initialize(cells, up = false, down = false)
		self.cells = cells
		self.touching_up = up
		self.touching_down = down
		self.normalize!
	end
	def size
		self.cells.size
	end
	def dup
		Signature.new(self.cells)
	end
	def least_unused_value
		((1..self.cells.length).to_a - self.cells.compact).min
	end
	def no_cells_remaining?
		self.cells.compact.empty?
	end
	def convert_all_cells(from, to)
	 		self.cells.collect!{|z| ((z == from)?(to):(z))}
	end
	def legal?
		self.touching_up and self.touching_down and connected?
	end
	def normalize!
		number_of_values = self.cells.compact.uniq.length
		self.cells.collect!{|x| x && x.to_s} #so we won't overwrite cells, and nil stays nil
		(0...number_of_values).each{|i| convert_all_cells(self.cells.find{|t| String === t},i)}
		return self
	end
	def merge_components(x,y)
		common_value = [self.cells[x], self.cells[y]].min
		other_value = [self.cells[x], self.cells[y]].max
		convert_all_cells(other_value,common_value)
	end
	def appears_once?(val)
		self.cells.find_all{|t| t==val}.length == 1
	end
	def has_two_components?
		self.cells.compact.uniq.length > 1
	end
	def connected?
		not has_two_components?
	end
	def disconnects?(at)
		return true if (self.cells[at]) and appears_once?(self.cells[at]) and has_two_components?
		return true if at > 0 and (self.cells[at-1]) and appears_once?(self.cells[at-1]) and has_two_components?
	end
	def succ_0(at)
		raise "adding at #{at} but size is #{size}" if at < 0 or at >= size
		temp = Signature.new(self.cells.dup, self.touching_up, self.touching_down)
		return :fail if disconnects?(at)
		temp.cells[at] = nil
		return ((temp.legal?)?(:add):(:fail)) if temp.no_cells_remaining?
		return temp.normalize!
	end
	def succ_1(at)
		raise "adding at #{at} but size is #{size}" if at < 0 or at >= size
		temp = Signature.new(self.cells.dup, self.touching_up, self.touching_down)
		if at == 0
			temp.touching_up = true
			temp.cells[at] = least_unused_value if temp.cells[at] == nil #otherwise, stays the same component
		else
			temp.touching_down = true if at == size - 1
			if temp.cells[at-1] == nil
				temp.cells[at] = least_unused_value if temp.cells[at] == nil #otherwise, stays the same component
			else
				temp.merge_components(at, at-1) if temp.cells[at] != nil
				temp.cells[at] = temp.cells[at-1] if temp.cells[at] == nil
			end
		end
		return temp.normalize!
	end
	def print(at)
		raise "inspecting at #{at} but size is #{size}" if at < 0 or at >= size
		puts "signature at #{at}"
		self.cells.each_index{|i| puts "#{((i < at)?(" "):(""))}#{self.cells[i] || "-"}#{((i == at)?("x"):(""))}"}
	end
	def eql?(other)
		self.cells.eql?(other.cells) and self.touching_up == other.touching_up and self.touching_down == other.touching_down
	end
	def ==(other)
		self.cells == other.cells and self.touching_up == other.touching_up and self.touching_down == other.touching_down
	end
	def hash
		(self.cells + [self.touching_up, self.touching_down]).hash
	end
	def inspect
		"(#{self.cells.inspect}#{(touching_up)?(", up"):("")}#{(touching_down)?(", down"):("")})"
	end
end

class JensenCounter
    attr_accessor :signatures, :counts, :final_count
    def initialize
	init
    end
    def init
            @counts = {}
            @final_count = []
            @signatures = []
    end
    def debug_print(text)
            puts text if $DebugPrint
    end

    def run_round(at)
            debug_print "************Round(#{at})******************"
            debug_print "Signatures currently are: #{@signatures.inspect}"
            debug_print "current counts: #{counts.inspect}"
            new_signatures = []
            new_counts = {}
            @signatures.each do |sig|
                    debug_print "considering signature #{sig.inspect}"
                    succ_0 = sig.succ_0(at)
                    succ_1 = sig.succ_1(at)
                    debug_print "succ_0 = #{succ_0.inspect} and succ1=#{succ_1.inspect}"
                    case succ_0
                        when :add then @final_count = @final_count.simple_sum(@counts[sig]) if sig.legal?
                        when Signature
                                new_counts[succ_0] = @counts[sig].simple_sum(new_counts[succ_0] || [])
                                new_signatures << succ_0
                        when :fail then  #do nothing
                    end

                    new_counts[succ_1] = counts[sig].shift_right.simple_sum(new_counts[succ_1] || [])
                    new_signatures << succ_1
            end
            @signatures = new_signatures.uniq
            @counts = new_counts
            debug_print "Round ended. Current signatures: #{@signatures.inspect}"
            debug_print "current count: #{@final_count.inspect}"
            debug_print "current counts: #{@counts.inspect}"
    end

    def count(height, width)
	init
	height.times do |at| #this is the first, special round
	    base_cells = [nil] * height
	    base_cells[at] = 0
	    new_sig = Signature.new(base_cells, at == 0, at == height - 1)
	    @signatures << new_sig
	    @counts[new_sig] = [1]
	    run_round(at+1) unless at == height - 1
	end
	(width - 1).times do |i| #minus 1 since the first column is "finished"
		height.times do |at|
		    run_round(at)
		end
	end
	@signatures.each{|sig| @final_count = @final_count.simple_sum(@counts[sig]) if sig.legal?}
	return @final_count
    end
    def count_for_size(n)
	(1..n).inject([]){|sum, k| sum.simple_sum(count(k,n))}[0...n]
    end
end
# puts JensenCounter.new.count(1,2).inspect
puts JensenCounter.new.count_for_size(7).inspect
# s = Signature.new([1,78,3,1])
# s.print(2)
# puts initial_signatures(4).inspect
