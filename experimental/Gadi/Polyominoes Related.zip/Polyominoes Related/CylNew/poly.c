#include <string.h>
#include <stdlib.h>
#include <stdio.h> 
#include <math.h>

#define NUMITER 9000
#define NMAX 30
#define odd(x) ((x) & 1)

#define twopower80 (((float) (1LL<<40))*((float) (1LL<<40)))
#define twopowerminus100 1/(((float) (1LL<<50))*((float) (1LL<<50)))


/*no allibero*/

 int size_of_set[NMAX];
 int set[NMAX][NMAX];

#define report (1==1) // TRUE

void motzkinpath2setofsets(int *p, int *outset, int n){
  /* , int size_of_set[NMAX], int set[NMAX][NMAX]){ */
  
  int ind, i,j, level;  

  ind= 0;
  level= 0;
  
  for(i= 0; i<=n-1 ; i++){
    switch(p[i]){
    case 1: 
      level++;
      if(odd(level)){                 /*start a new set set[(level-1)/2]*/
	size_of_set[level>>1]= 0;
      }
      break;
    case -1: 
      if(odd(level)){                 /*current set is complete; store set[(level-1)/2]*/
	for(j= 0;j<size_of_set[level>>1];) outset[ind++]= set[level>>1][j++];
	outset[ind++]= 0;        
      }
      level--;
      break;
    } 
    if(odd(level)){                   /*add i+1 (els elements van de 1..n) to current set*/
      set[level>>1][size_of_set[level>>1]++]= i+1;
    }
  }
  outset[ind++]= 0;                   /*add another final terminal marker*/
}

void generate_motzkinpath( unsigned int **stock, int n, int maxstock){

  int i, row, col, height;
 
  /* altura 0..maxstock */ 

  stock[0][n]=1;
  for (i=1 ; i<= maxstock ; i++) {
    stock[i][n-i+1]=0; 
    stock[i][n-i+2]=0;
  }
  
  for (col = n-1; col >= 0 ; col--){
  
    if (col < maxstock)  height = col;                           /* col < n- col */
    else if (col > maxstock +1 ) height = n-col;                 /* col > n- col */
    else if (col == maxstock + 1 && !odd(n))  height = n-col;
    else {                                          /* col = n-col = maxstock, highest stock a part*/
      height = maxstock -1; 
      stock[height+1][col] = stock[height][col+1]+stock[height+1][col+1];
    }

    stock[0][col] = stock[0][col+1]+ stock[1][col+1];                                                     

    for (row = 1 ; row <= height ; row++)
      stock[row][col] = stock[row-1][col+1]+stock[row][col+1]+stock[row+1][col+1]; 
  }
}

void number2motzkinpath(int np, int *p, unsigned int **stock, int n,  int maxstock){

  int h, col, num;

  h = 0;
  num = np;

  for(col=0 ; col <= n-1; col++){ 
    if (h == 0){   
      if (stock[0][col+1]>=num) p[col] = 0;                
      else{
        p[col] = 1;
        num = num-stock[h][col+1]; 
        h++;
      }              
    }                                                                                  
    else{      
      if (stock[h-1][col+1]>=num){
        p[col]=-1;
        h--;    
      }                                                              
      else if (stock[h-1][col+1]+stock[h][col+1]>=num){
        p[col]=0; 
        num = num-stock[h-1][col+1];         
      }                                                            
      else{ 
        p[col]=1; 
        num=num-stock[h-1][col+1]-stock[h][col+1];
        h++;   
      } 
    } 
  }
}

unsigned int motzkinpath2number(int *p, unsigned int **stock){

  int h, i;
  unsigned int min;
 
  h=0;
  min=1;   
  /* la i enlloc de 1 comenca per 0*/

  for(i = 0; stock[h][i] != 1; i++){ 
    if ( p[i] == 1 ){
      if (h>0) min = min + stock[h-1][i+1]+stock[h][i+1];
      else     min = min + stock[h][i+1];
      h++;
    }
    else if (p[i]==-1) h--; 
    else
      if (h>0) min = min + stock[h-1][i+1]; 
  }  
  return(min);
}
 
int *shifting_(int *p, int n){

  int i; 
  
  for(i=n-1 ;i >= 1; i--) p[i] = p[i-1];
  p[0]=0; 
  return(p);
}

int* shiftingw(int *p, int n){

  int i,level,last;
                                                                                                                       
  if (p[n-2]==1){   
    p[n-1]=0;
    for (i = n-2; i>=2; i--) p[i] = p[i-1];
    p[0]=1;
    p[1]=-1;                                                    
  }
  else{  
    last=n-2;
    level=1-p[last];   
    while (level!=1){  
      p[last+1]=p[last];
      last--;
      level=level-p[last];
    }                                                         
    if (last < n-2){ 
       p[n-1]=0;
       p[last+1]=-1;
    }                                                                         
    last--;
    level=level-p[last];  
    while (level != 0){ 
      p[last+1]=p[last];
      last--;
      level=level-p[last];
    }                                       
    if (last==0){
      p[0]=1;
      p[1]=0;
      return(p);                                                                               
    }   
    p[last+1]=-1;    
    for (i=last ;i>= 2 ; i--) p[i]=p[i-1]; 
    p[0]=1;
    p[1]=1;
  }                                                                                                   
  return(p);
}


 int w, n, j, k, first, last, level, maxstock, scaled, checkratio;
 float minvalue, maxvalue;
 double vap, minratio, maxratio;
 unsigned int i, M;
 char ch;

 float *new, *old, *temp;
 unsigned int *succ0, *succ1;
 int *p, *paux, *tempp, *setofsets;

 unsigned int **stock;

 double ratio, oldratio=1e100;

/*#include "printnums.c"*/

 void printSucc(unsigned int size){
	unsigned int i;
	for (i=0; i<size; i++)
		printf("%d:[%d,%d]\n",i,succ0[i],succ1[i]);
}
void printVector(float* vector,unsigned int size){
	unsigned int i;
	for (i=0; i<size; i++)
		printf("%d: %f\n",i,vector[i]);
}

int main(int argc, char **argv){

 if (argc < 2){ 
   printf("Error, w?\n");
   exit(0);
 }

 w = atoi(argv[1]);

 n = w+1;
 maxstock = n/2;  /* floor, son enters.  L'altura es maxstock+1  */ 
 
 stock=(unsigned int **)malloc((maxstock + 1) * sizeof(unsigned int *));
 if (stock==0) {printf("Error malloc stock\n"); exit(1);}
 for (j = 0; j < maxstock + 1 ; j++){
   stock[j] = (unsigned int *)malloc((n+1) * sizeof(unsigned int));
   if (stock[j]==0) {printf("Error malloc stock\n"); exit(1);}
 }

 generate_motzkinpath(stock,n,maxstock);
 M=stock[0][0];
 
//  printf("n = %d, W = %d, M = %lu\n long long = %d bytes, unsigned int = %d bytes, unsigned long = %d bytes, unsigned long long = %d bytes\n pointer = %d bytes, size_t (for malloc) = %d bytes\n",
//      n, n-1 , M,
//      sizeof(long long) , sizeof(unsigned int),
//      sizeof(unsigned long ), sizeof(unsigned long long),
//      sizeof(succ0),sizeof(size_t));
 /*scanf("%c",&ch);*/

 succ0 = (unsigned int *)malloc((long long)(M - 1) * sizeof(unsigned int));
 if (succ0==0) {printf("Error malloc succ0\n"); exit(1);}

 succ1 = (unsigned int *)malloc((long long)(M -1) * sizeof(unsigned int));
 if (succ1==0) {printf("Error malloc succ1\n"); exit(1);}

 p = (int *)malloc(n * sizeof(int));
 if (p==0) {printf("Error malloc p\n"); exit(1);}

 paux = (int *)malloc(n * sizeof(int));
 if (paux==0) {printf("Error malloc paux\n"); exit(1);}

 new = (float *)malloc((long long)(M - 1) * sizeof(float));
 if (new==0) {printf("Error malloc new\n"); exit(1);}

 old = (float *)malloc((long long)(M - 1) * sizeof(float));
 if (old==0) {printf("Error malloc old\n"); exit(1);}

 printf("Memory OK\n");

 for(i=2; i<=M; i++){

   /* states van de 0 a M-2, i succ0 sera nul quan succ0=-1 */
   /* resto -1 als indexos perque els vectors amb C van de 0..n-1*/
   if(report) {
     if(i%1000000==0 ) { printf("G%u ",i/1000000); fflush(0);}
     if(i<1000000 && i%100000==0 ) { printf("g%u ",i/100000); fflush(0);}
   }

   number2motzkinpath(i, p, stock, n, maxstock);

   if (p[n-1]==0){
     memcpy(paux, p, sizeof(int) * n);
     succ0[i-2]=motzkinpath2number(shifting_(paux,n),stock)-2; 
   }  
   else{   
     memcpy(paux, p, sizeof(int) * n);                         /* paux = p */
     
     if (p[n-2]==0){   
       paux[n-2]=-1;    
       paux[n-1]=0;
       
       succ0[i-2]=motzkinpath2number(shifting_(paux,n),stock)-2;
     }
     else if (p[n-2]==-1){     
       paux[n-1]=0; 
       paux[n-2]=0;  
       last=n-3;
       level=2-paux[last];       
       
       while (level>1){
	 last--;
	 level=level-paux[last];
       }
       paux[last]=-1;
       
       succ0[i-2]=motzkinpath2number(shifting_(paux,n),stock)-2;       
     }
     else{
       succ0[i-2]=-1;          
     }  
   }
   if(p[0]==1){  
     if(p[n-1]==-1){             /* p[1]=1 and p[n]=-1 */     
       last=n-2;
       level=1-p[last];
       
       while (level>0){
	 last--;
	 level=level-p[last];
       }         
       if(last>0){
	 p[last]=-1;
	 first=1; 
	 level=1+p[first];             
	 
	 while(level>0){
	   first++; 
	   level=level+p[first];
	 }                                                       
	 p[first]=1;                                                                                      
       }   
       succ1[i-2]=motzkinpath2number(shiftingw(p,n),stock)-2;                                                         
     }   
     else{                         /* p[1]=1 and p[n]=0 */ 
       shifting_(p,n); 
       p[0]=1; 
       p[1]=0; 
        succ1[i-2]=motzkinpath2number(p,stock)-2;
     }
   }                                                                                                      
   else{          
      if(p[n-1]==-1) succ1[i-2]=motzkinpath2number(shiftingw(p,n),stock)-2;    /* p[1]=0 and p[n]=-1 */ 
      else{                       /* p[1]=0 and p[n]=0 */   
        shifting_(p,n);
        p[0]=1;
        p[1]=-1;
        succ1[i-2]=motzkinpath2number(p,stock)-2;
      }
   }
 } 
 printf("Successor generated, begin iteration \n");
 /*
	printSucc(M-1);
	exit(1);
*/
 for (i=0 ; i <= M-2 ; i++) {
   old[i]=1.;
   if(report && i%10000000==0 ) { printf("i%u ",i/10000000); fflush(0);}
 }
 
 setofsets = (int *)malloc(n * sizeof(int));
 if (setofsets==0) {printf("Error malloc setofsets\n"); exit(1);}
 
 scaled=0;
 for (j=0; j < NUMITER ; j++){
   if (report) printf("ITER %d\n", j);
   checkratio = j%10==0 && j>0;
for (k=0; k<1; k++){
   // Unrolling of loop. take out first iteration:
   if (succ0[0] != -1) new[0] = new[succ0[0]]+old[succ1[0]];
   else new[0] = old[succ1[0]];
   minratio = maxratio = new[0]/(double)old[0];
   maxvalue = minvalue = new[0];
   for(i=1; i<=M-2; i++){
     if(report && i%10000000==0 ) { printf("%u ",i/10000000); fflush(0);}
     if (succ0[i] != -1) new[i] = new[succ0[i]]+old[succ1[i]];
     else new[i] = old[succ1[i]];

     if (maxvalue < new[i]) maxvalue = new[i];
     if (minvalue > new[i]) minvalue = new[i];

     if(checkratio) {
       /* find min and max */
       vap = new[i]/(double)old[i];
       if (vap < minratio) minratio = vap;
       else if (vap > maxratio) maxratio = vap;
     }
   } 
   temp=new;                        /*old=new*/
   new=old; 
   old=temp;

}
/*	printVector(old,M-1);
	exit(1);*/
   if (checkratio) {
     
     if (report) printf("\n");
     printf("iter %d: min= %0.9f, max= %0.9f, ratio=%0.9f\n",j,
	    minratio,maxratio,maxratio/minratio);
     ratio = maxratio/minratio;

     /*     if (max<1.000002*min){ */
     if (ratio>=oldratio){ /* no improvement, STOP */
       printf("Scaled %i times\n ", scaled);

       if (argc > 2){ ch=argv[2][0]; }
//        else {
/*	 printf("Do you want to see the (scaled) eigenvector (y/n)?\n ");
	 scanf("%c",&ch);
       }
       if (ch=='y'){
        printcheck();
       }*/
       exit(0);
     }
     oldratio = ratio;
   }
   if(report)
     printf(" newmin= %g, newmax= %g, ratio=%g , %f\n", minvalue,
	    maxvalue, maxvalue/minvalue, twopower80);
   /* rescale if necessary */
   if (maxvalue > twopower80){
     printf(" newmin= %g, newmax= %g, ratio=%g , %f\n", minvalue,
	    maxvalue, maxvalue/minvalue, twopower80);
     for(i=0 ; i <= M-2 ; i++) new[i]*=twopowerminus100;
     scaled++;  
   }

   temp=new;                        /*old=new*/
   new=old; 
   old=temp;
 }                               
 exit (0);
}
