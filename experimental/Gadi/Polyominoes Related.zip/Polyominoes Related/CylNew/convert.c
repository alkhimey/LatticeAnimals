#define odd(x) ((x) &1)  \

/*1:*/
#line 4 "convert.web"

/*2:*/
#line 15 "convert.web"

ind= 0;
for(i= 0,level= 0;i<=w;i++){
switch(symbol[i]){
case up:
level++;
if(odd(level)){
size_of_set[level>>1]= 0;
}
break;
case down:
if(odd(level)){
/*4:*/
#line 40 "convert.web"

for(i= 0;i<size_of_set[level>>1];)outset[ind++]= set[level>>1][i++];
outset[ind++]= 0;

/*:4*/
#line 27 "convert.web"
;
}
level--;
break;
}
if(odd(level)){/*3:*/
#line 37 "convert.web"

set[level>>1][size_of_set[level>>1]++]= i;

/*:3*/
#line 32 "convert.web"
;}
}
outset[ind++]= 0;


/*:2*/
#line 5 "convert.web"
;
/*5:*/
#line 44 "convert.web"


for(f= 0;f<w;f++)ch[f]= '0';
ind= 0;
while(f= outset[ind++]){
if(outset[ind]){
ch[f]= '(';
while(f= outset[ind]){ch[f]= '-';ind++;}
ch[outset[ind-1]]= ')';
}
else ch[f]= '1';
ind++;
}

/*:5*/
#line 6 "convert.web"
;

/*:1*/
