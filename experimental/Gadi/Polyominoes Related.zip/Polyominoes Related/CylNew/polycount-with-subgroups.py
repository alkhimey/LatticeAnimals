## version with separate files.
## sorting is checked


from polystate import State

w = 8
nmax = 20

d = {}
# SIMULATE with a dictionary instead of file

def start():
    # write first files
  for k in range(1,2):
    fstartname = 'f%d-1-%d' % (w,k)
#    fstart = open(fstartname,"w")
    d[fstartname]=[ '0'*(k-1)+'1'+'0'*(w-k)+' 1\n' ]
#    fstart.write('1'+'0'*(w-1)+' 1\n')
#    fstart.close()

def checksorted(l):
    prev = None
    for x in l:
        x=x.split()[0]
        if prev and prev>x:
            return False
        prev=x
    return True

def countsorted(l):
    prev = None
    eq=less=more=0
    for x in l:
        x=x.split()[0]
        if prev:
          if prev>x:
            more +=1
          elif prev<x:
            less +=1
          else:
            eq +=1
        prev=x
    return less,eq,more

def run():
  for n in range(1,nmax+1):
    for k in range(1,w+1):
        # sort finname
        finname = 'f%d-%d-%d' % (w,n,k)
        fout1name = 'f%d-%d-%d' % (w,n+1,1)
        fout0name = 'f%d-%d-%d' % (w,n,k+1)
#        fin = open(finname,"r")
        fin = d[finname]
        if k>1:
            if not checksorted(fin):
                raise ValueError(fin)
        else:
            less,eq,more= countsorted(fin)
            print n, " <",less," =",eq," >",more," total =",len(fin),
            fin.sort()
        if k==1:
            fout1 = d[fout1name]=[]
#            fout1 =open(fout1name,"w")
##        else:
##            fout1 =open(fout1name,"a")
        if k<w:
            fout0 = d[fout0name]=[]
#            fout0 =open(fout0name,"w")
        else:
            fout0 = None
        currentstate = None
        for l in fin:
            l1 = l.split()
            s = State(l1[0])
            v = int(l1[1])
            #print n,k,currentstate,s,v
            if not (currentstate is None) and (s==currentstate):
                currentvalue += v
            else:
                if currentstate: finalize(currentstate,currentvalue,fout0,fout1)
                currentstate = s
                currentvalue = v
        finalize(currentstate,currentvalue,fout0,fout1) # always at least 1 state per file

#        fin.close()
#        if k==w: fout1.close()
#        if fout0: foul0.close

nprev = 1
def finalize(s,v,fout0,fout1):
    global nprev
    if str(s)=='0'*(w-1)+'1':
        print s,v,1.*v/nprev
        nprev=v
    fout1.append("%s %d" % (str(s.succ1()),v))
#    fout1.write("%s %d\n" % (str(s.succ1),v))
    s0 = s.succ0()
    if s0:
       fout0.append("%s %d" % (str(s0),v))
       #fout0.write("%s %d\n" % (str(s0),v))
       
start()
run()        
                
