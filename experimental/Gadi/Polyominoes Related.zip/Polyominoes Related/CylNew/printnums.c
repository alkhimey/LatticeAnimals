/* #include <stdio.h>
/* #include <math.h> */
#include "/usr/i486-linuxlibc1/include/i386/ieeefp.h"

char sbuf[200];
#define MULTI (1LL<<36)
#define twopower63 (((float) (1LL<<31))*((float) (1LL<<32)))
#define twopower25 ((float) (1LL<<25))

FILE* out;

void printset(long long ii){
  number2motzkinpath(ii, p, stock, n, maxstock);
  motzkinpath2setofsets(p,setofsets,n);
  k=0;
  fprintf(out,"{");
  while (setofsets[k]!=0){
    fprintf(out,"{"); 
    while(setofsets[k]!=0){
      fprintf(out,"%d",setofsets[k]);
      k++;
      if(setofsets[k]!=0) fprintf(out,","); 
    }
    fprintf(out,"}");

    k++;  
    if(setofsets[k]!=0) fprintf(out,","); 
  } 
  fprintf(out,"},");
}


char * printexact (float x){
  int ex = 0;
  if (x<=0 || !finite(x)) return "error";
  while (x>=twopower63) { x *= (1/(float)MULTI); ex++; }
  while (x< twopower25) { x *=    (float)MULTI ; ex--; }
  if (ex==0) sprintf(sbuf,"%lld", (long long)x);
  else if (abs(ex)==1)
         sprintf(sbuf,"%lld%c%lld",    (long long)x, (ex>0?'*':'/'), MULTI);
  else   sprintf(sbuf,"%lld%c%lld^%d", (long long)x, (ex>0?'*':'/'), MULTI, abs(ex));
  return sbuf;
}

void printcheck(){
  char fname[50];
  sprintf(fname,"check-poly-%d.maple",n-1);
  out=fopen(fname,"w");
  fprintf(out,"read \"procfile.maple\":\ninit(%d):\n",n-1);
  for(i=0 ;i <= M-2; i++){ 
    if (succ0[i]!=-1) {
      fprintf(out,"setx(");
      printset(succ0[i]+2); fprintf(out,"%s,1):\n",printexact(new[succ0[i]]));
    }
    fprintf(out,"setx(");
    printset(succ1[i]+2); fprintf(out,"%s,1):\n",printexact(new[succ1[i]]));
    fprintf(out,"setx(");
    printset(i+2); fprintf(out,"%s,0):\n",printexact(new[i]));
  }
  fprintf(out,"finish():\nterminate():\nsetx := checkx:\n");
  fclose(out);
}

/*
main () {
  float x=2./3.;
  int i;
  for (i=0;i<50;i++) {
    x*=23;
    printf("%d %s %g \n",i, printexact(x),(double)x);
  }
}
*/
