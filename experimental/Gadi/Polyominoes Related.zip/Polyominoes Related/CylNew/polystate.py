from types import *

def decode(c):
    if '0'<=c<='9':
        return int(c)
    elif 'A'<=c.upper()<='Z':
        return ord(c.upper())-ord('A')+10
    else:
        raise ValueError()

def encode(v):
    if 0<=v<=9:
        return str(v)
    elif 10<=v<=35:
        return chr(ord('A')+v-10)
    else:
        raise ValueError()

class State:
  def __init__(self,s):
      if type(s) is ListType:
        self.s = s
      elif type(s) is StringType:
        self.s = map(decode,s)
      else:
        raise TypeError
  def __eq__(self,other):
      return self.s == other.s
  def __ne__(self,other):
      return self.s != other.s
  def succ0(self):
    k = self.s[-1]
    if k>0 and self.s.index(k)==len(self.s)-1:
        return None # succ0 does not exist
    return State([0]+self.s[:-1])

  def succ1(self):
    k = self.s[-1]; l = self.s[0]
    if k>0 and l==0:
        # k is united with (new) 1:
        # k becomes 1, all blocks between are shifted up
        def shiftindex(x):
            if x==k:
                return 1
            elif 0<x<k:
                return x+1
            else:
                return x
    elif k>1 and l==1:
        # k is united with (old) 1:
        # k becomes 1, all higher blocks are shifted down
        def shiftindex(x):
            if x==k:
                return 1
            elif x>k:
                return x-1
            else:
                return x
    elif (k==0 or k==1) and l==1:
        # 1 is united with (old) 1:
        # nothing changes
        return State([1]+self.s[:-1])
    else: # k==l==0: new isolated block 1: everything is shifted up
        def shiftindex(x):
            if x==0:
                return x
            else:
                return x+1
    return State([1]+map(shiftindex,self.s[:-1]))

  def __repr__(self):
      return(''.join(map(encode,self.s)))
    
    
