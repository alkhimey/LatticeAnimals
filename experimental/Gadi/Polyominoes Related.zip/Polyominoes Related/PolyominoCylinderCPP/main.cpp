/* 
 * File:   main.cpp
 * Author: gadial
 *
 * Created on September 12, 2010, 2:22 PM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}

