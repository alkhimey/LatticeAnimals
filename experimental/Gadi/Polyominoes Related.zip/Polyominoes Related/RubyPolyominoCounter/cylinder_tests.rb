require 'polyominocounter'
class Grid
	def find_empty_column
		(0...self.cylinder_width).find{|i| not self.squares.find{|s| s.x == i}}
	end
	def shrink
		t = find_empty_column
		return nil unless t != nil
		new_grid = self.dup
		new_grid.squares.collect! do |s|
			new_s = s.dup
			new_s.x = s.x - 1 if s.x > t
			new_s
		end
		new_grid
	end
end

def print_polyominoes(polyominoes)
        polyominoes.each{|x| puts x.inspect}
end

def draw_polyominoes(polyominoes, filename,directory = "images")
	polyomino_images = Magick::ImageList.new
        polyominoes.each_index{|i| x=polyominoes[i]; polyomino_images << x.draw(40)}
        polyomino_images.write("#{directory}/#{filename}.png")
end

def generate_adjacent_values(cylinder_width, n)
	run1_options = {:n => n, :d => 2, :verbose => true, :cylinder => cylinder_width - 1}
	run2_options = {:n => n, :d => 2, :verbose => true, :cylinder => cylinder_width}
	run1 = RedelmeierAlgorithm.new(run1_options)
	run1.run
	# puts run1.polyominoes
	# puts "*" * 50
	
	run2 = RedelmeierAlgorithm.new(run2_options)
	run2.run
	# puts run2.polyominoes
	a = run2.polyominoes[n-1]
	b = run1.polyominoes[n-1]
	
	a_set = a.dup
	b_set = b.dup
	
	a.each do |p|
		puts "a_set.size = #{a_set.size}, b_set.size = #{b_set.size}"
		if b_set.include?(p)
			b_set.delete(p)
			a_set.delete(p)
			next
		end
	end
	
	a.each do |p|
		puts "a_set.size = #{a_set.size}, b_set.size = #{b_set.size}"
		if b_set.include?(p.shrink)
			b_set.delete(p.shrink)
			a_set.delete(p)
			next
		end
	end
	# puts "a_set.size = #{a_set.size}, b_set.size = #{b_set.size}"
	return [a_set,b_set]
end
n = 6
a_sets = (3..n).collect{|k| generate_adjacent_values(k,n).first}
a_sets.each_index{|k| draw_polyominoes(a_sets[k],"cylinder-#{k+3}","test2")}
# diff = 3
# ((diff+2)..9).each{|n| a_set,b_set = generate_adjacent_values(diff,n); puts "a_set.size = #{a_set.size}, b_set.size = #{b_set.size}"}
# n = 8

# a_set,b_set = generate_adjacent_values(diff,10)
# puts "a_set.size = #{a_set.size}, b_set.size = #{b_set.size}"
# puts a_set
# puts "*" * 50
# puts b_set

# Dir.mkdir("test-3-n-#{n}")
# draw_polyominoes(a_set,"a_pol","test-3-n-#{n}")
# draw_polyominoes(b_set,"b_pol","test-3-n-#{n}")
