require 'polyominocounter'
require 'test/unit'

class CylinderTest < Test::Unit::TestCase
	def test_neighbors
		square = Square.new([1,1])
		n = square.calculate_neighbors
		assert(n.include? Square.new([0,1]))
		assert(n.include? Square.new([1,0]))
		assert(n.include? Square.new([2,1]))
		assert(n.include? Square.new([1,2]))
		
		square = Square.new([1,1])
		n = square.calculate_neighbors(2)
		assert(n.include? Square.new([0,1]))
		assert(n.include? Square.new([1,0]))
		assert(n.include? Square.new([2,1]))
		assert(n.include? Square.new([2,0]))
		
		square = Square.new([1,0])
		n = square.calculate_neighbors(2)
		assert(n.include? Square.new([1,1]))
		assert(n.include? Square.new([0,0]))
		assert(n.include? Square.new([2,0]))
		assert(n.include? Square.new([0,1]))
	end
end