require 'rubygems'
require 'RMagick'

gc = Magick::Draw.new
gc.stroke('black')
stroke_width = 6
gc.stroke_width(stroke_width)
gc.fill('red')
gc.translate(40,40)
gc.polygon(-40,-40,10,40,40,40,40,10)

canvas = Magick::Image.new(100,100){self.background_color = 'white'}
gc.draw(canvas)
canvas.display